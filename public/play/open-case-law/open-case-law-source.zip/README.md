# Open Case Law

MIT-licensed legal research tools. No example case corpus or personal research is included.

## Browser workspace

Run `node server/dev.mjs 8080` (Node 22+) and open http://127.0.0.1:8080.
The static browser app uses a same-origin search relay locally. In production on
EvolveTech, it calls the Netlify search relay so both static hosting providers work.
Use server/search.mjs as a Netlify function handler, with a wrapper exporting
`config = {path: "/api/case-law/search"}`; configure
the allowed origins in that file and the API origin in web/discovery.mjs for another host.
The relay uses CourtListener's documented public Atom search feed, without an API key.
It returns a limited recent-match set (up to 20, newest first), not exhaustive relevance
ranking. Original opinion links open CourtListener. Preview snippets are not full opinions.

Cases, imported source text, and notes save automatically to browser IndexedDB.
Download a JSON backup for portability; restore by importing it. Search queries are sent
to EvolveTech and CourtListener and may appear in provider logs. Imported documents and
notebooks are not uploaded. No analytics or third-party JavaScript is loaded.

Features: live case discovery, court/name/citation search modes, saved cases, exact quote
checks, source snapshots, JSON/Markdown export, ranked local search, multi-query fusion,
and phrase concordance. Advanced research labels are optional.

## Python CLI

Python 3.10+, standard library, SQLite FTS5. From this directory:

    python3 -m caselaw --help
    python3 -m caselaw --db corpus.sqlite init
    python3 -m caselaw --db corpus.sqlite add opinion.txt --title 'An opinion' --publication published
    python3 -m caselaw --db corpus.sqlite search 'notice hearing' --source-only

Other commands: research, triage, citations, concordance, compare, audit, issue, note,
matrix, export, import-leads, lead-attempt, leads. `triage plan.json` fuses distinct
local searches and reports matching queries, source-quality flags, candidate caps,
and identical text IDs. A plan has `queries: [{"query":"notice"},{"query":"hearing"}]`
and optional filters such as `{"source_only": true, "publication":"published"}`.

The optional Python CLI CourtListener API discovery and opinion download require your own API token and permissions.
Set COURTLISTENER_TOKEN privately in your shell; it is never supplied by this release.
The browser live search uses the public feed, separate from that authenticated CLI API.

Evidence labels are researcher assessments. Exact quote checking validates a substring
against imported text, not authenticity or legal meaning. Publication and disposition
metadata are not independently verified. This is not a citator, legal opinion, guarantee
of exhaustive search, or certification that an authority is controlling or current.

## Validation

    python3 -m unittest discover -s tests -q
    node --test web/engine.test.mjs server/search.test.mjs
    # With pip install playwright and Chrome installed:
    python3 tests/browser_e2e.py

The release includes focused, topic-independent tests. No provider credentials or live
authenticated API verification are included. See LICENSE for the MIT license.
