# Open Case Law

MIT-licensed legal research tools. No example case corpus or personal research is included.

## Browser workspace

Serve `web/` with any static web server, e.g. `python3 -m http.server 8080 --directory web`.
Import UTF-8 text or CLI-compatible JSON document arrays. Source text, search queries and
evidence notes remain in memory in the browser tab. Export a workspace JSON before closing;
import that file to restore the sources and source-snapshot evidence. No automatic saving.
External research links send the displayed query only when followed.

Features: ranked local source search, reciprocal-rank fusion across query lines,
phrase concordance, source reader, publication/status review flags, exact quote checks,
passage-role labels, source snapshots, JSON and Markdown export. Synthetic demo text is
explicitly fictional. No API, authentication, telemetry or third-party script is loaded.

## Python CLI

Python 3.10+, standard library, SQLite FTS5. From this directory:

    python3 -m caselaw --help
    python3 -m caselaw --db corpus.sqlite init
    python3 -m caselaw --db corpus.sqlite add opinion.txt --title 'An opinion' --publication published
    python3 -m caselaw --db corpus.sqlite search 'notice hearing' --source-only

Other commands: research, triage, citations, concordance, compare, audit, issue, note,
matrix, export, import-leads, lead-attempt, leads. `triage plan.json` fuses distinct
local searches and reports matching queries, source-quality flags, candidate caps,
and identical text IDs. A plan has `queries: [{"query":"notice"},{"query":"hearing"}]`
and optional filters such as `{"source_only": true, "publication":"published"}`.

CourtListener discovery and opinion download require your own API token and permissions.
Set COURTLISTENER_TOKEN privately in your shell; it is never supplied by this release.
CourtListener and Scholar links are prepared searches, not searches the tool has executed.

Evidence labels are researcher assessments. Exact quote checking validates a substring
against imported text, not authenticity or legal meaning. Publication and disposition
metadata are not independently verified. This is not a citator, legal opinion, guarantee
of exhaustive search, or certification that an authority is controlling or current.

## Validation

    python3 -m unittest discover -s tests -q
    node --test web/engine.test.mjs

The release includes focused, topic-independent tests. No provider credentials or live
authenticated API verification are included. See LICENSE for the MIT license.
