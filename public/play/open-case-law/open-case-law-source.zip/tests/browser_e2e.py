"""Real browser acceptance checks. pip install playwright; Chrome must be installed.
Run python3 tests/browser_e2e.py. Set CASE_LAW_URL to test an existing deployment;
set CASE_LAW_LIVE=1 for additional unmocked CourtListener search smoke checks.
Only generic software fixtures are used; no family research is included.
"""
import json
import os
from pathlib import Path
import socket
import subprocess
import tempfile
import time
import urllib.request
from playwright.sync_api import sync_playwright, expect

ROOT = Path(__file__).resolve().parents[1]
TEXT = 'SOFTWARE TEST ONLY. The court considered adequate notice before the hearing. This is not a real opinion.'
ATOM = '''<?xml version="1.0"?><feed xmlns="http://www.w3.org/2005/Atom"><entry>
<title>Software test record — not legal authority</title><link rel="alternate" href="https://www.courtlistener.com/opinion/1/software-test/"/>
<published>2000-01-01T00:00:00Z</published><author><name>Software test court</name></author>
<summary type="html">&lt;p&gt;A discovery preview, not an opinion.&lt;/p&gt;&lt;img src="https://invalid.example/test" onerror="window.injected=true"&gt;&lt;script&gt;window.injected=true&lt;/script&gt;</summary>
</entry></feed>'''


def checks(base):
    with sync_playwright() as p, tempfile.TemporaryDirectory() as td:
        browser = p.chromium.launch(executable_path=os.getenv('CHROME_BIN', '/usr/bin/google-chrome'), headless=True, args=['--no-sandbox'])
        context = browser.new_context(accept_downloads=True)
        page = context.new_page()
        errors = []
        page.on('pageerror', lambda e: errors.append(str(e)))
        requests = []
        page.on('request', lambda r: requests.append(r.url))
        api = '**/api/case-law/search?*'
        def fixture(route):
            route.fulfill(headers={'Access-Control-Allow-Origin':'*'}, json={'xml': ATOM, 'query': 'notice hearing', 'retrieved_at': '2026-01-01T00:00:00Z'})
        page.route(api, fixture)
        page.goto(base)
        expect(page.locator('#storage-status')).not_to_have_text('Opening browser storage…')
        page.locator('#query').fill('notice hearing')
        page.locator('#search-button').click()
        expect(page.locator('#results-title')).to_have_text('1 recent matching case')
        assert not page.evaluate('Boolean(window.injected)')
        alternative = page.locator('#results').get_by_role('link', name='Find another copy')
        assert 'google.com/search?' in alternative.get_attribute('href')
        assert 'Software+test+record' in alternative.get_attribute('href')
        assert not any('invalid.example' in r for r in requests)
        page.locator('#results button[data-save]').click()
        expect(page.locator('#count')).to_have_text('1')
        expect(page.locator('#storage-status')).to_contain_text('Saved automatically')
        page.reload()
        expect(page.locator('#count')).to_have_text('1')
        page.locator('[data-tab=saved]').click()
        page.locator('#library').get_by_role('button', name='Notes & saved text').click()
        expect(page.locator('#reader-kind')).to_contain_text('Search preview only')
        page.locator('#toggle-note').click()
        page.locator('#note').fill('Review the original before relying on this.')
        page.locator('#note-form details').first.locator('summary').click()
        page.locator('#quote').fill('A discovery preview, not an opinion.')
        page.locator('#pinpoint').fill('p. 1')
        page.locator('#note-form button[type=submit], #note-form button.primary').click()
        expect(page.locator('#note-message')).to_contain_text('discovery snippets cannot be quoted')
        page.locator('#quote').fill('')
        page.locator('#note-form button.primary').click()
        expect(page.locator('#case-notes .card')).to_have_count(1)
        page.locator('#edit-text').click()
        page.locator('#source-text').fill(TEXT)
        page.locator('#text-form button.primary').click()
        expect(page.locator('#reader-kind')).to_contain_text('Selected passage')
        page.locator('#note').fill('Checked the text supplied for this software test.')
        page.locator('#quote').fill('An invented quotation.')
        page.locator('#pinpoint').fill('p. 1')
        page.locator('#note-form button.primary').click()
        expect(page.locator('#note-message')).to_contain_text('exact source quotation')
        page.locator('#quote').fill('The court considered adequate notice before the hearing.')
        page.locator('#note-form button.primary').click()
        expect(page.locator('#case-notes .card')).to_have_count(2)
        page.locator('#edit-text').click()
        page.locator('#source-text').fill(TEXT+' Later imported context.')
        page.locator('#text-form button.primary').click()
        page.locator('#close-reader').click()
        expect(page.locator('#storage-status')).to_contain_text('Saved automatically')
        with page.expect_download() as download:
            page.locator('#export-notes').click()
        backup = Path(td) / 'backup.json'
        download.value.save_as(backup)
        data = json.loads(backup.read_text())
        assert len(data['sources']) == 1 and len(data['notes']) == 2
        assert data['notes'][1]['source']['text'] == TEXT
        assert data['sources'][0]['text'].endswith('Later imported context.')
        assert all(n['position'] == 'unreviewed' for n in data['notes'])
        original_dates = [n['added_at'] for n in data['notes']]
        page.locator('summary', has_text='Delete browser data').click()
        page.once('dialog', lambda d: d.accept())
        page.locator('#clear').click()
        expect(page.locator('#count')).to_have_text('0')
        expect(page.locator('#storage-status')).to_contain_text('Saved automatically')
        page.reload()
        expect(page.locator('#count')).to_have_text('0')
        page.locator('[data-tab=saved]').click()
        page.locator('summary', has_text='Import opinions').click()
        page.locator('#import').set_input_files(backup)
        expect(page.locator('#count')).to_have_text('1')
        expect(page.locator('#storage-status')).to_contain_text('Saved automatically')
        page.reload()
        expect(page.locator('#count')).to_have_text('1')
        page.locator('[data-tab=saved]').click()
        with page.expect_download() as download:
            page.locator('#export-notes').click()
        restored = Path(td) / 'restored.json'
        download.value.save_as(restored)
        assert [n['added_at'] for n in json.loads(restored.read_text())['notes']] == original_dates
        page.locator('#library').get_by_role('button', name='Notes & saved text').click()
        expect(page.locator('#case-notes .card')).to_have_count(2)
        page.locator('#close-reader').click()
        page.locator('[data-tab=find]').click()
        page.unroute(api, fixture)
        page.locator('#query').fill('notice hearing')
        page.route(api, lambda route: route.fulfill(status=502, headers={'Access-Control-Allow-Origin':'*'}, json={'error': 'Provider temporarily unavailable.'}))
        page.locator('#search-button').click()
        expect(page.locator('#results-title')).to_have_text('Search unavailable')
        expect(page.locator('#results')).to_contain_text('Provider temporarily unavailable')
        expect(page.locator('#more-results')).to_be_visible()
        expect(page.locator('#search-button')).to_be_enabled()
        page.unroute(api)
        page.route(api, lambda route: route.fulfill(headers={'Access-Control-Allow-Origin':'*'}, json={'xml':'<feed xmlns="http://www.w3.org/2005/Atom"/>','query':'nothing'}))
        page.locator('#search-button').click()
        expect(page.locator('#results-title')).to_have_text('No cases returned')
        page.unroute(api)
        page.route(api, lambda route: route.fulfill(headers={'Access-Control-Allow-Origin':'*'}, json={'xml':'<html>blocked</html>'}))
        page.locator('#search-button').click()
        expect(page.locator('#results-title')).to_have_text('Search unavailable')
        page.unroute(api)
        pending = []
        page.route(api, lambda route: pending.append(route))
        page.locator('#search-button').click()
        expect(page.locator('#cancel-search')).to_be_visible()
        page.locator('#cancel-search').click()
        expect(page.locator('#results-title')).to_have_text('Search cancelled')
        for route in pending:
            try: route.abort()
            except Exception: pass
        page.unroute(api)
        if os.getenv('CASE_LAW_LIVE') == '1':
            for mode, query in [('name','Miranda v. Arizona'),('citation','384 U.S. 436'),('keywords','vehicle warrant')]:
                page.locator('#query').fill(query)
                page.locator('#search-mode').select_option(mode)
                page.locator('#search-button').click()
                expect(page.locator('#results-title')).to_contain_text('recent matching', timeout=30000)
                assert page.locator('#results .card').count() > 0
                assert 'courtlistener.com/opinion/' in page.locator('#results .card a').first.get_attribute('href')
                print('LIVE SEARCH:', mode, query, page.locator('#results-title').inner_text())
            page.screenshot(path='/tmp/open-case-law-new-desktop.png', full_page=True)
        page.set_viewport_size({'width':390,'height':844})
        assert page.evaluate('document.documentElement.scrollWidth <= innerWidth')
        page.locator('[data-tab=saved]').click()
        page.locator('#library').get_by_role('button', name='Notes & saved text').click()
        assert page.locator('#reader').evaluate('(e)=>e.scrollWidth <= e.clientWidth')
        page.screenshot(path='/tmp/open-case-law-new-mobile.png', full_page=True)
        assert not errors, errors
        browser.close()
        print('PASS: find/save/reload, snippet guard, exact quotes, snapshots, backup/restore, failures, empty, cancellation, mobile, no script errors')


if __name__ == '__main__':
    base = os.getenv('CASE_LAW_URL')
    process = None
    try:
        if not base:
            with socket.socket() as s:
                s.bind(('127.0.0.1',0))
                port = s.getsockname()[1]
            process = subprocess.Popen(['node','server/dev.mjs',str(port)],cwd=ROOT)
            base = f'http://127.0.0.1:{port}/'
            for _ in range(100):
                try:
                    urllib.request.urlopen(base,timeout=1).close()
                    break
                except OSError: time.sleep(.1)
        checks(base)
    finally:
        if process:
            process.terminate()
            process.wait(timeout=5)
