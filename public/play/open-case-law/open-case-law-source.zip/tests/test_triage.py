import tempfile
import unittest
from pathlib import Path
from caselaw.store import connect, import_records
from caselaw.triage import rank_plan


class TriageTests(unittest.TestCase):
    def test_fusion_and_source_quality_remain_separate(self):
        with tempfile.TemporaryDirectory() as directory:
            db = connect(Path(directory) / 'db')
            import_records(db, [dict(id='both', title='Both topics', text='Notice before public hearings.', publication='unpublished'),
                                dict(id='one', title='One topic', text='Notice.', publication='published'),
                                dict(id='summary', title='Summary', text='Notice public hearings.', content_type='research_summary'),
                                dict(id='copy', title='Copy', text='Notice.', publication='published')])
            plan = {'queries': [{'query':'notice'}, {'query':'hearings'}, {'query':'notice'}]}
            report = rank_plan(db, plan)
            self.assertEqual(len(report['searches']), 2)
            self.assertEqual(report['results'][0]['document']['id'], 'both')
            self.assertNotIn('summary', [e['document']['id'] for e in report['results']])
            self.assertTrue(any('Publication' in f for f in report['results'][0]['authority_review']['flags']))
            one = next(e for e in report['results'] if e['document']['id'] == 'one')
            self.assertEqual(one['identical_text_ids'], ['copy'])
            limited = rank_plan(db, plan, per_query=1, limit=1)
            self.assertTrue(limited['searches'][0]['candidate_cap_reached'])
            self.assertEqual(len(limited['results']), 1)
            with self.assertRaises(ValueError): rank_plan(db, plan, limit=0)
            db.close()
