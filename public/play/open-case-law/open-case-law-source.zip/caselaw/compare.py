"""Source-only word comparisons with exact character spans and review context."""
from difflib import SequenceMatcher
import re
from .sources import audit_document


def compare_sources(db, before_id, after_id, *, limit=30, ignore_case=False,
                    before_start=0, before_end=None, after_start=0, after_end=None):
    if type(limit) is not int or not 1 <= limit <= 100:
        raise ValueError('Comparison limit must be between 1 and 100')
    selected=[]
    for identity,start,end in ((before_id,before_start,before_end),(after_id,after_start,after_end)):
        row=db.execute('SELECT * FROM documents WHERE id=?',(identity,)).fetchone()
        if not row:
            raise ValueError('Unknown comparison document: '+identity)
        doc=dict(row)
        if doc['content_type'] not in ('source_excerpt','full_text'):
            raise ValueError('Comparisons require source text/excerpts, not summaries or discovery snippets')
        end=len(doc['text']) if end is None else end
        if type(start) is not int or type(end) is not int or not 0 <= start <= end <= len(doc['text']):
            raise ValueError('Comparison range must be ordered character offsets within the source')
        tokens=list(re.finditer(r'\S+',doc['text'][start:end]))
        if len(tokens)>3000:
            raise ValueError('Select at most 3000 words per source using character ranges')
        selected.append((doc,start,end,tokens))

    def span(side,first,last):
        doc,start,end,tokens=selected[side]
        a=start+tokens[first].start() if first<len(tokens) else end
        b=start+tokens[last-1].end() if last>first else a
        return dict(document_id=doc['id'],start=a,end=b,text=doc['text'][a:b])

    words=[[m.group().casefold() if ignore_case else m.group() for m in side[3]] for side in selected]
    # A bounded input avoids unbounded quadratic comparisons on repetitive text.
    changes=[]
    for tag,i,j,k,l in SequenceMatcher(None,*words,autojunk=False).get_opcodes():
        if tag!='equal':
            changes.append(dict(change=tag,before=span(0,i,j),after=span(1,k,l)))
    sources=[]
    for doc,start,end,tokens in selected:
        audit=audit_document(doc)
        sources.append(dict(id=doc['id'],title=doc['title'],citation=doc['citation'],url=doc['url'],
            kind=doc['kind'],publication=doc['publication'],court=doc['court'],jurisdiction=doc['jurisdiction'],date=doc['date'],
            content_type=doc['content_type'],sha256=doc['sha256'],selected_start=start,selected_end=end,
            selected_word_count=len(tokens),authority=audit['authority'],review_flags=audit['flags']))
    return dict(before=sources[0],after=sources[1],ignore_case=ignore_case,
        total_changes=len(changes),changes=changes[:limit],truncated=len(changes)>limit,
        warning='Textual comparison only; before/after are caller-supplied labels, not verified chronology. Whitespace-only changes are ignored. Different excerpts or rendering artifacts can cause apparent changes. A change does not establish amendment, repeal, legislative intent, or legal effect; unchanged excerpts do not establish identical law.')
