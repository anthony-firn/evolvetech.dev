"""SQLite FTS5 corpus, provenance, and issue-specific research notebooks."""
import hashlib
import json
import re
import sqlite3
from datetime import datetime, timezone
from pathlib import Path

KINDS = ('opinion', 'statute', 'rule', 'form', 'guidance', 'other')
POSITIONS = ('supports', 'contrary', 'distinguishes', 'background', 'unreviewed')
PASSAGE_ROLES = ('unclassified', 'holding', 'judicial_reasoning', 'party_argument',
                 'factual_background', 'statutory_text', 'agency_instruction', 'commentary')
ISSUE_FITS = ('unassessed', 'direct', 'analogical', 'background')


def now():
    return datetime.now(timezone.utc).isoformat()


def connect(path):
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    db = sqlite3.connect(path)
    db.row_factory = sqlite3.Row
    db.execute('PRAGMA foreign_keys=ON')
    db.executescript('''
        CREATE TABLE IF NOT EXISTS documents (
            id TEXT PRIMARY KEY, title TEXT NOT NULL, citation TEXT NOT NULL,
            court TEXT NOT NULL, jurisdiction TEXT NOT NULL, date TEXT NOT NULL,
            kind TEXT NOT NULL, publication TEXT NOT NULL, url TEXT NOT NULL,
            text TEXT NOT NULL, content_type TEXT NOT NULL,
            retrieved_at TEXT NOT NULL, sha256 TEXT NOT NULL, metadata TEXT NOT NULL
        );
        CREATE VIRTUAL TABLE IF NOT EXISTS search_index USING fts5(
            title, citation, text, content='documents', content_rowid='rowid',
            tokenize='unicode61 remove_diacritics 2'
        );
        CREATE TRIGGER IF NOT EXISTS documents_ai AFTER INSERT ON documents BEGIN
            INSERT INTO search_index(rowid,title,citation,text)
            VALUES(new.rowid,new.title,new.citation,new.text);
        END;
        CREATE TRIGGER IF NOT EXISTS documents_ad AFTER DELETE ON documents BEGIN
            INSERT INTO search_index(search_index,rowid,title,citation,text)
            VALUES('delete',old.rowid,old.title,old.citation,old.text);
        END;
        CREATE TRIGGER IF NOT EXISTS documents_au AFTER UPDATE ON documents BEGIN
            INSERT INTO search_index(search_index,rowid,title,citation,text)
            VALUES('delete',old.rowid,old.title,old.citation,old.text);
            INSERT INTO search_index(rowid,title,citation,text)
            VALUES(new.rowid,new.title,new.citation,new.text);
        END;
        CREATE TABLE IF NOT EXISTS issues (
            id INTEGER PRIMARY KEY, title TEXT NOT NULL, question TEXT NOT NULL,
            created_at TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS evidence (
            id INTEGER PRIMARY KEY, issue_id INTEGER NOT NULL REFERENCES issues(id),
            document_id TEXT NOT NULL REFERENCES documents(id),
            position TEXT NOT NULL, note TEXT NOT NULL, quote TEXT NOT NULL,
            pinpoint TEXT NOT NULL, added_at TEXT NOT NULL, source_snapshot TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS searches (
            id INTEGER PRIMARY KEY, query TEXT NOT NULL, provider TEXT NOT NULL,
            filters TEXT NOT NULL, result_count INTEGER NOT NULL, searched_at TEXT NOT NULL
        );
    ''')
    columns = {row['name'] for row in db.execute('PRAGMA table_info(evidence)')}
    for column, default in (('passage_role', 'unclassified'), ('issue_fit', 'unassessed')):
        if column not in columns:
            db.execute(f"ALTER TABLE evidence ADD COLUMN {column} TEXT NOT NULL DEFAULT '{default}'")
    db.commit()
    return db


def put_document(db, record):
    record = dict(record)
    title = record.get('title', '').strip()
    text = record.get('text', '').strip()
    if not title or not text:
        raise ValueError('Every document needs nonempty title and text')
    kind = record.get('kind', 'opinion')
    if kind not in KINDS:
        raise ValueError(f'Invalid kind: {kind}')
    content_type = record.get('content_type', 'full_text')
    if content_type not in ('full_text', 'source_excerpt', 'snippet', 'research_summary'):
        raise ValueError('content_type must be full_text, source_excerpt, snippet, or research_summary')
    identity = record.get('id') or hashlib.sha256(
        (record.get('url') or title + '\n' + record.get('citation', '')).encode()
    ).hexdigest()[:20]
    values = dict(id=identity, title=title, text=text, kind=kind,
                  content_type=content_type, retrieved_at=record.get('retrieved_at') or now(),
                  sha256=hashlib.sha256(text.encode()).hexdigest(),
                  metadata=json.dumps(record.get('metadata', {}), ensure_ascii=False))
    for field in ('citation', 'court', 'jurisdiction', 'date', 'url'):
        values[field] = record.get(field, '')
    values['publication'] = record.get('publication', 'unknown')
    fields = list(values)
    # Keep rowids stable so FTS and notebook references survive re-imports.
    db.execute(f"INSERT INTO documents ({','.join(fields)}) VALUES ({','.join('?' for _ in fields)}) "
               'ON CONFLICT(id) DO UPDATE SET ' + ','.join(f'{k}=excluded.{k}' for k in fields if k != 'id'),
               list(values.values()))
    return identity


def import_records(db, records):
    if not isinstance(records, list):
        raise ValueError('Import must be a JSON array of document objects')
    with db:
        return [put_document(db, record) for record in records]


def import_discovery_records(db, records):
    """Save provider snippets without downgrading captured opinion sources."""
    if not isinstance(records, list):
        raise ValueError('Discovery records must be a list')
    imported, preserved = [], []
    with db:
        for record in records:
            if not isinstance(record,dict) or not isinstance(record.get('id'), str) or not record['id'] or record.get('content_type') != 'snippet':
                raise ValueError('Discovery records require explicit IDs and snippet content type')
            existing = db.execute('SELECT content_type FROM documents WHERE id=?',(record['id'],)).fetchone()
            if existing and existing['content_type'] in ('full_text','source_excerpt'):
                preserved.append(record['id'])
            else:
                imported.append(put_document(db,record))
    return dict(imported_ids=imported,preserved_source_ids=preserved)


def search(db, query, *, raw=False, mode='all', limit=20, **filters):
    # Literal mode safely handles citations, punctuation and hostile FTS syntax.
    terms = re.findall(r'\w+', query, flags=re.UNICODE)
    expression = query if raw else (' OR ' if mode == 'any' else ' AND ').join(
        '"' + term + '"' for term in terms)
    if not expression:
        raise ValueError('Enter at least one searchable word')
    clauses, params = ['search_index MATCH ?'], [expression]
    for field in ('court', 'jurisdiction', 'kind', 'publication', 'content_type'):
        if filters.get(field):
            clauses.append(f'd.{field} = ? COLLATE NOCASE')
            params.append(filters[field])
    if filters.get('source_only'):
        clauses.append("d.content_type IN ('full_text', 'source_excerpt')")
    for name, operator in (('after', '>='), ('before', '<=')):
        if filters.get(name):
            clauses.append(f'd.date {operator} ? AND d.date != \'\'')
            params.append(filters[name])
    rows = db.execute('''SELECT d.*, bm25(search_index,5,8,1) AS rank,
        snippet(search_index,2,'[',']',' … ',42) AS excerpt
        FROM search_index JOIN documents d ON d.rowid=search_index.rowid WHERE '''
        + ' AND '.join(clauses) + ' ORDER BY rank,d.id LIMIT ?', params + [limit]).fetchall()
    with db:
        db.execute('INSERT INTO searches(query,provider,filters,result_count,searched_at) VALUES(?,?,?,?,?)',
                   (query, 'local', json.dumps(dict(filters, raw=raw, mode=mode)), len(rows), now()))
    return [dict(row) for row in rows]


def add_evidence(db, issue_id, document_id, position, note='', quote='', pinpoint='',
                 passage_role='unclassified', issue_fit='unassessed'):
    doc = db.execute('SELECT * FROM documents WHERE id=?', (document_id,)).fetchone()
    if not doc:
        raise ValueError('Unknown document ID')
    if position not in POSITIONS:
        raise ValueError('Invalid position')
    if passage_role not in PASSAGE_ROLES or issue_fit not in ISSUE_FITS:
        raise ValueError('Invalid passage role or issue fit')
    if (passage_role != 'unclassified' or issue_fit != 'unassessed') and not quote:
        raise ValueError('Classified evidence needs an exact source quotation and pinpoint')
    if passage_role in ('holding', 'judicial_reasoning') and doc['kind'] != 'opinion':
        raise ValueError('Judicial passage roles require an opinion source')
    metadata = json.loads(doc['metadata'])
    if passage_role == 'holding' and metadata.get('authority', {}).get('stage', 'unverified') != 'final':
        raise ValueError('A holding label requires a researcher-verified final disposition')
    if passage_role == 'holding' and re.search(r'dissent|concurrence', str(metadata.get('opinion_type', '')), re.I):
        raise ValueError('A separate dissent or concurrence cannot be labeled a holding of the court')
    if quote:
        if doc['content_type'] not in ('full_text', 'source_excerpt'):
            raise ValueError('A quotation requires imported full text or a source excerpt; summaries/snippets are discovery only')
        if quote not in doc['text']:
            raise ValueError('Quote is not an exact substring of the stored source text')
        if not pinpoint.strip():
            raise ValueError('A quotation needs a pinpoint (page or paragraph)')
    with db:
        return db.execute('''INSERT INTO evidence
            (issue_id,document_id,position,note,quote,pinpoint,added_at,source_snapshot,passage_role,issue_fit)
            VALUES(?,?,?,?,?,?,?,?,?,?)''',
            (issue_id, document_id, position, note, quote, pinpoint, now(), json.dumps(dict(doc), ensure_ascii=False), passage_role, issue_fit)).lastrowid


def export_issue(db, issue_id):
    issue = db.execute('SELECT * FROM issues WHERE id=?', (issue_id,)).fetchone()
    if not issue:
        raise ValueError('Unknown issue ID')
    rows = db.execute('''SELECT e.*,d.title,d.citation,d.court,d.url,d.publication,
        d.content_type,d.retrieved_at,d.sha256 FROM evidence e
        JOIN documents d ON d.id=e.document_id WHERE issue_id=? ORDER BY e.id''', (issue_id,)).fetchall()
    lines = [f"# {issue['title']}", '', issue['question'], '',
             'Research notebook. Positions and notes are researcher assessments; publication metadata',
             'does not establish precedential force or current validity. Later treatment is not verified.', '']
    for position in POSITIONS:
        lines += [f'## {position.capitalize()}', '']
        entries = [row for row in rows if row['position'] == position]
        if not entries:
            lines += ['No evidence recorded.', '']
        for entry in entries:
            row = dict(entry)
            snapshot = json.loads(row['source_snapshot'])
            changed = row['sha256'] != snapshot['sha256']
            row.update(snapshot)
            if changed:
                lines += ['Source text has changed since this evidence was recorded; the snapshot below preserves the reviewed version.', '']
            lines += [f"### {row['title']}", '', f"Citation: {row['citation'] or 'not supplied'}",
                      f"Court: {row['court'] or 'not supplied'}",
                      f"Source: {row['url'] or 'local import'}",
                      f"Publication: {row['publication']}; content: {row['content_type']}",
                      f"Researcher passage role: {row['passage_role']}; issue fit: {row['issue_fit']}", '', row['note'], '']
            if row['quote']:
                lines += ['> ' + row['quote'].replace('\n', '\n> '), '', f"Pinpoint: {row['pinpoint']}", '']
            lines += [f"Retrieved: {row['retrieved_at']}; text SHA-256: {row['sha256']}", '']
    return '\n'.join(lines)


def evidence_matrix(db, issue_id):
    """Expose reviewed passages and gaps without calculating a legal verdict."""
    from .sources import audit_document
    issue = db.execute('SELECT * FROM issues WHERE id=?', (issue_id,)).fetchone()
    if not issue:
        raise ValueError('Unknown issue ID')
    entries = []
    for row in db.execute('SELECT * FROM evidence WHERE issue_id=? ORDER BY id', (issue_id,)):
        entry = dict(row)
        snapshot = json.loads(entry.pop('source_snapshot'))
        current = dict(db.execute('SELECT * FROM documents WHERE id=?', (entry['document_id'],)).fetchone())
        entry['source'] = {k: snapshot[k] for k in ('id', 'title', 'citation', 'url', 'publication', 'content_type', 'sha256')}
        entry['authority'] = json.loads(snapshot['metadata'])
        entry['source_changed'] = current['sha256'] != snapshot['sha256']
        entry['authority_changed'] = current['metadata'] != snapshot['metadata'] or any(
            current[k] != snapshot[k] for k in ('publication', 'court', 'date', 'kind'))
        entry['audit'] = audit_document(snapshot)
        entries.append(entry)
    return {'issue': dict(issue), 'assessment_basis': 'Researcher labels, not automatic legal conclusions; no verified citator.',
            'entries': entries,
            'missing_positions': [p for p in ('supports', 'contrary') if not any(e['position'] == p for e in entries)],
            'has_researcher_labeled_direct_holding': any(e['passage_role'] == 'holding' and e['issue_fit'] == 'direct' for e in entries)}
