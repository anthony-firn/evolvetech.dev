"""Fuse independent local searches without pretending scores measure legal force."""
import json
from .research import build_queries
from .sources import audit_document
from .store import search


def rank_plan(db, plan, *, limit=30, per_query=100):
    if not 1 <= limit <= 100 or not 1 <= per_query <= 500:
        raise ValueError('Use limit 1–100 and per_query 1–500')
    filters = dict(plan.get('filters', {}))
    allowed = {'court', 'jurisdiction', 'kind', 'publication', 'content_type', 'source_only', 'after', 'before'}
    if set(filters) - allowed:
        raise ValueError('Unsupported research plan filters')
    filters.setdefault('source_only', True)
    candidates, coverage = {}, []
    for query in build_queries(plan):
        rows = search(db, query['local_query'], raw=query['raw'], limit=per_query, **filters)
        coverage.append({'label': query['label'], 'query': query['local_query'],
                         'returned': len(rows), 'candidate_cap_reached': len(rows) == per_query})
        for rank, row in enumerate(rows, 1):
            entry = candidates.setdefault(row['id'], {'document': dict(row), 'rrf_score': 0.0, 'matched_queries': []})
            entry['rrf_score'] += 1 / (60 + rank)
            entry['matched_queries'].append({'label': query['label'], 'rank': rank, 'excerpt': row['excerpt']})
    ordered = sorted(candidates.values(), key=lambda e: (-e['rrf_score'], e['document']['id']))
    for entry in ordered:
        doc = entry['document']
        entry['authority_review'] = audit_document(doc)
        # Identical source text may be multiple captures, not independent authorities.
        entry['identical_text_ids'] = [other['document']['id'] for other in ordered
                                       if other['document']['id'] != doc['id'] and other['document']['sha256'] == doc['sha256']]
        entry['document'] = {k: doc[k] for k in ('id', 'title', 'citation', 'court', 'publication', 'date', 'url', 'content_type', 'sha256')}
    return {'title': plan.get('title', 'Research triage'), 'filters': filters, 'searches': coverage,
            'candidates_found': len(candidates), 'results': ordered[:limit], 'truncated': len(ordered) > limit,
            'method': 'Reciprocal rank fusion (k=60) over distinct plan queries; source-only by default.',
            'warning': 'Lexical relevance only. No conclusion about holdings, controlling authority, support, or later treatment. Identical text is not independent corroboration.'}
