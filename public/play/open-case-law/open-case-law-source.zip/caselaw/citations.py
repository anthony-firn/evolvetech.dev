"""Conservative local citation extraction and source-only citation links.

Supports common US federal, regional, California and New York reporters.
This is not a complete citation parser, citator, or treatment classifier.
"""
import json
import re
from .providers import search_links

REPORTER = r'''(?:
    U\.?\s*S\.? |
    S\.?\s*Ct\.? |
    L\.?\s*Ed\.?(?:\s*2d)? |
    F\.?(?:\s*(?:Supp\.?(?:\s*(?:2d|3d))?|2d|3d|4th))? |
    Cal\.?(?:\s*App\.?)?(?:\s*(?:2d|3d|4th|5th))? |
    P\.?(?:\s*(?:2d|3d))? |
    A\.?(?:\s*(?:2d|3d))? |
    N\.?\s*E\.?(?:\s*(?:2d|3d))? |
    N\.?\s*W\.?(?:\s*2d)? |
    S\.?\s*E\.?(?:\s*2d)? |
    S\.?\s*W\.?(?:\s*(?:2d|3d))? |
    So\.?(?:\s*(?:2d|3d))? |
    N\.?\s*Y\.?(?:\s*S\.?)?(?:\s*(?:2d|3d))?
)'''
CITATION = re.compile(r'(?<![\w.])(?P<volume>\d{1,4})\s*(?P<reporter>' + REPORTER +
                      r')\s+(?P<page>\d{1,6})(?!\w)', re.VERBOSE)


def citation_key(volume, reporter, page):
    return f'{int(volume)}:{re.sub(r"[^a-z0-9]", "", reporter.lower())}:{int(page)}'


def extract_citations(text, *, radius=180):
    if not 0 <= radius <= 2000:
        raise ValueError('Citation context radius must be between 0 and 2000')
    result = []
    for match in CITATION.finditer(text):
        start, end = match.span()
        result.append(dict(citation=match.group(), key=citation_key(**match.groupdict()),
                           volume=int(match['volume']), reporter=match['reporter'], page=int(match['page']),
                           start=start, end=end, context_start=max(0, start-radius),
                           context_end=min(len(text), end+radius),
                           context=text[max(0,start-radius):min(len(text),end+radius)]))
    return result


def index_citations(db):
    db.executescript('''
        CREATE TABLE IF NOT EXISTS citation_index_state (
            document_id TEXT PRIMARY KEY REFERENCES documents(id) ON DELETE CASCADE,
            source_signature TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS citation_mentions (
            document_id TEXT NOT NULL REFERENCES documents(id) ON DELETE CASCADE,
            source_sha256 TEXT NOT NULL, citation_key TEXT NOT NULL,
            citation TEXT NOT NULL, start INTEGER NOT NULL, end INTEGER NOT NULL,
            PRIMARY KEY(document_id,start,end)
        );
        CREATE INDEX IF NOT EXISTS citation_key_index ON citation_mentions(citation_key);
    ''')
    count = 0
    with db:
        for record in db.execute('SELECT id,text,sha256,content_type,kind FROM documents').fetchall():
            signature = ':'.join(record[k] for k in ('sha256','content_type','kind'))
            old = db.execute('SELECT source_signature FROM citation_index_state WHERE document_id=?', (record['id'],)).fetchone()
            if old and old['source_signature'] == signature:
                continue
            db.execute('DELETE FROM citation_mentions WHERE document_id=?', (record['id'],))
            if record['kind'] == 'opinion' and record['content_type'] in ('full_text','source_excerpt'):
                mentions = extract_citations(record['text'])
                db.executemany('INSERT INTO citation_mentions VALUES(?,?,?,?,?,?)',
                    [(record['id'],record['sha256'],m['key'],m['citation'],m['start'],m['end']) for m in mentions])
                count += len(mentions)
            db.execute('INSERT INTO citation_index_state VALUES(?,?) ON CONFLICT(document_id) DO UPDATE SET source_signature=excluded.source_signature',
                       (record['id'],signature))
    return count


def citation_graph(db, document_id, *, direction='outgoing', limit=50):
    if direction not in ('outgoing','incoming') or not 1 <= limit <= 100:
        raise ValueError('Invalid citation direction or limit')
    record = db.execute('SELECT * FROM documents WHERE id=?', (document_id,)).fetchone()
    if not record:
        raise ValueError('Unknown document ID')
    index_citations(db)
    # A reporter citation may identify multiple local records or versions.
    targets = {}
    for doc in db.execute("SELECT id,title,citation,url,publication,content_type,metadata FROM documents WHERE kind='opinion'"):
        for citation in extract_citations(doc['citation']):
            targets.setdefault(citation['key'], []).append(dict(doc))
    if direction == 'incoming':
        keys = sorted({m['key'] for m in extract_citations(record['citation'])})
        if not keys:
            raise ValueError('This document has no recognized reporter citation; incoming coverage is unavailable')
        clauses = 'm.citation_key IN (' + ','.join('?' for _ in keys) + ') AND m.document_id != ?'
        params = keys + [document_id]
    else:
        clauses, params = 'm.document_id=?', [document_id]
    rows = db.execute('''SELECT m.*,d.title,d.url,d.publication,d.content_type,d.text,d.metadata
        FROM citation_mentions m JOIN documents d ON d.id=m.document_id
        WHERE ''' + clauses + ' ORDER BY m.document_id,m.start LIMIT ?', params+[limit+1]).fetchall()
    result = []
    for row in rows[:limit]:
        meta = json.loads(row['metadata'])
        result.append(dict(source_id=row['document_id'], source_title=row['title'], source_url=row['url'],
                           source_publication=row['publication'], source_content_type=row['content_type'],
                           source_authority=meta.get('authority', {}), source_sha256=row['source_sha256'],
                           citation=row['citation'], key=row['citation_key'], start=row['start'],end=row['end'],
                           context=row['text'][max(0,row['start']-180):min(len(row['text']),row['end']+180)],
                           local_targets=[{k: t[k] for k in ('id','title','citation','url','publication','content_type')}
                                          for t in targets.get(row['citation_key'], [])]))
    follow_up = {}
    for mention in result:
        key = mention['key']
        if key not in follow_up:
            matches = mention['local_targets']
            source_available = any(t['content_type'] in ('full_text', 'source_excerpt') for t in matches)
            follow_up[key] = dict(citation=mention['citation'], key=key,
                coverage='source_available' if source_available else 'discovery_only' if matches else 'not_imported',
                local_ids=[t['id'] for t in matches], source_ids=[],
                links=search_links('"' + mention['citation'] + '"'))
        if mention['source_id'] not in follow_up[key]['source_ids']:
            follow_up[key]['source_ids'].append(mention['source_id'])
    return dict(document_id=document_id,direction=direction,mentions=result,follow_up=list(follow_up.values()),truncated=len(rows)>limit,
                coverage='Only current imported opinion source text/excerpts and supported reporter formats; summaries and discovery snippets excluded.',
                warning='A citation is not approval. Context may quote a party or discuss adverse treatment. Missing local edges do not establish absence of citing decisions. Follow-up links are prepared searches, not completed lookups; they cover only returned mentions.')
