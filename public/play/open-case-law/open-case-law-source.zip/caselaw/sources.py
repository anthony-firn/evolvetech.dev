"""Traceable import of line-numbered web captures and source-quality review."""
import hashlib
import json
import re

LINE = re.compile(r'^L(?P<number>\d+)(?:@P[\d-]+)?: ?(?P<text>.*)$')


def capture_record(capture, *, title, url, start, end, citation='', court='', jurisdiction='',
                   kind='opinion', publication='unknown', date='', metadata=None):
    """Import selected rendered source text, preserving line bounds and raw capture.

    A selected body stays an excerpt: this importer cannot certify that a web
    renderer supplied the entire original opinion, OCR, or link-only citations.
    """
    if start < 0 or end < start or end - start > 100000:
        raise ValueError('Capture bounds must be ordered nonnegative line numbers spanning at most 100001 lines')
    lines = {}
    for line in capture.splitlines():
        match = LINE.match(line)
        if match:
            number = int(match['number'])
            if number in lines and lines[number] != match['text']:
                raise ValueError('Capture contains conflicting source line numbers')
            lines[number] = match['text']
    missing = [number for number in range(start, end + 1) if number not in lines]
    if missing:
        raise ValueError(f'Capture is incomplete for requested range; missing line {missing[0]}')
    text = '\n'.join(lines[number] for number in range(start, end + 1)).strip()
    if not text:
        raise ValueError('Selected capture range is empty')
    meta = dict(metadata or {})
    meta.update(source_capture_sha256=hashlib.sha256(capture.encode()).hexdigest(),
                source_capture=capture, source_line_start=start, source_line_end=end,
                extraction='line-numbered rendered web text',
                extraction_warning='Selected rendered text only; original completeness and transcription are not certified.')
    return dict(title=title, url=url, citation=citation, court=court, jurisdiction=jurisdiction,
                kind=kind, publication=publication, date=date, text=text,
                content_type='source_excerpt', metadata=meta)


def audit_document(record):
    metadata = record.get('metadata', {})
    if isinstance(metadata, str):
        metadata = json.loads(metadata)
    authority = metadata.get('authority', {})
    flags = []
    if not record.get('url'):
        flags.append('Source URL not supplied')
    content = record['content_type']
    if content in ('research_summary', 'snippet'):
        flags.append('Discovery/interpretation only; not quotation source text')
    elif content == 'source_excerpt':
        flags.append('Selected source text; surrounding opinion or document must also be reviewed')
    if record['kind'] == 'opinion':
        stage = authority.get('stage', 'unverified')
        if stage != 'final':
            flags.append('Final disposition not verified' if stage == 'unverified' else f'Procedural stage: {stage}; do not treat as a final judgment')
        publication = record.get('publication', 'unknown').lower()
        if publication not in ('published', 'precedential'):
            flags.append('Publication/precedential status requires review')
        if not authority.get('treatment_checked_on'):
            flags.append('Later treatment not verified')
    if record['kind'] in ('statute', 'rule', 'form', 'guidance'):
        if not (authority.get('current_version_verified_on') or metadata.get('current_official_verified') is True):
            flags.append('Current official version not verified')
    fit = authority.get('issue_fit', 'unassessed')
    if fit != 'direct':
        flags.append(f'Relevance to exact question: {fit}')
    return dict(id=record['id'], title=record['title'], citation=record.get('citation', ''),
                url=record.get('url', ''), content_type=content,
                authority=authority, flags=flags,
                note='Flags and researcher-supplied metadata support review; absence of flags does not establish controlling law.')


def audit_issue(db, issue_id):
    issue = db.execute('SELECT * FROM issues WHERE id=?', (issue_id,)).fetchone()
    if not issue:
        raise ValueError('Unknown issue ID')
    entries = db.execute('SELECT * FROM evidence WHERE issue_id=? ORDER BY id', (issue_id,)).fetchall()
    records = {}
    for entry in entries:
        # Audit the frozen source actually assessed in this notebook.
        snapshot = json.loads(entry['source_snapshot'])
        key = (snapshot['id'], snapshot['sha256'], snapshot['metadata'])
        if key not in records:
            records[key] = audit_document(snapshot)
    return dict(issue=dict(issue), sources=list(records.values()),
                warning='This audit does not decide the legal question. Direct applicability, authority, disposition and later treatment need independent verification.')
