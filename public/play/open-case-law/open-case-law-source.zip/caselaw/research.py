"""Topic-independent concept expansion, passage retrieval, and citation follow-up."""
import itertools
import json
import re
from urllib.error import HTTPError, URLError
from .providers import discover, search_links
from .store import import_discovery_records, now, search


def build_queries(plan):
    """Use researcher-supplied synonyms; never guess a legal conclusion."""
    concepts = plan.get('concepts', [])
    if not isinstance(concepts, list) or len(concepts) > 6:
        raise ValueError('Use at most six concept groups')
    groups = []
    for concept in concepts:
        terms = concept.get('terms', [])
        if not terms or len(terms) > 6 or any(not isinstance(t, str) or not t.strip() for t in terms):
            raise ValueError('Each concept needs 1–6 nonempty terms')
        if any(len(t) > 200 for t in terms):
            raise ValueError('Concept terms must be at most 200 characters')
        # Terms are literal phrases, even if they contain boolean-looking words.
        local = '(' + ' OR '.join('"' + t.replace('"', '""') + '"' for t in terms) + ')'
        remote = '(' + ' OR '.join('"' + t.replace('\\', '\\\\').replace('"', '\\"') + '"' for t in terms) + ')'
        groups.append((concept.get('name', ', '.join(terms)), local, remote))
    queries = []
    if len(groups) >= 2:
        selections = [tuple(range(len(groups)))]
        if len(groups) > 2:
            selections.extend(itertools.combinations(range(len(groups)), 2))
        for indices in selections:
            queries.append(dict(label=' + '.join(groups[i][0] for i in indices),
                                purpose='concept overlap',
                                local_query=' AND '.join(groups[i][1] for i in indices),
                                query=' AND '.join(groups[i][2] for i in indices), raw=True))
    elif groups:
        queries.append(dict(label=groups[0][0], purpose='concept', local_query=groups[0][1],
                            query=groups[0][2], raw=True))
    for entry in plan.get('queries', []):
        if not isinstance(entry.get('query'), str) or not entry['query'].strip():
            raise ValueError('Each explicit query needs a nonempty query string')
        queries.append(dict(label=entry.get('label', entry['query']), purpose=entry.get('purpose', 'follow-up'),
                            query=entry['query'], local_query=entry.get('local_query', entry['query']),
                            raw='local_query' in entry))
    unique = {}
    for query in queries:
        unique.setdefault(query['query'], query)
    if not unique or len(unique) > 30:
        raise ValueError('A research plan must produce 1–30 unique queries')
    return list(unique.values())


def research(db, plan, *, live=False, pages=1, discover_fn=discover):
    queries = build_queries(plan)
    output = dict(title=plan.get('title', 'Research search plan'), question=plan.get('question', ''),
                  run_at=now(), live_requested=live, searches=[])
    filters = plan.get('filters', {})
    supported = {'court', 'jurisdiction', 'kind', 'publication', 'content_type', 'source_only', 'after', 'before'}
    if not isinstance(filters, dict) or set(filters) - supported:
        raise ValueError('Unsupported research plan filters')
    live_stopped = False
    for query in queries:
        entry = dict(query, links=search_links(query['query'], filters.get('court', '')))
        entry['live_status'] = 'not_requested'
        if live:
            # Unknown filters must not silently disappear from the remote search.
            if any(filters.get(k) for k in ('jurisdiction', 'kind', 'publication', 'content_type', 'source_only')):
                raise ValueError('Live plans support court/after/before filters; use CourtListener fielded queries for other constraints')
            if live_stopped:
                entry['live_status'] = 'skipped_after_provider_error'
            else:
                try:
                    records = discover_fn(query['query'], pages=pages,
                                          **{k: filters.get(k, '') for k in ('court', 'after', 'before')})
                    saved = import_discovery_records(db, records)
                    entry['discovery_imported'] = len(saved['imported_ids'])
                    entry['source_records_preserved'] = len(saved['preserved_source_ids'])
                    entry['live_status'] = 'completed'
                    entry['live_returned'] = len(records)
                    db.execute('INSERT INTO searches(query,provider,filters,result_count,searched_at) VALUES(?,?,?,?,?)',
                               (query['query'], 'CourtListener', json.dumps(filters), len(records), now()))
                except (HTTPError, URLError) as exc:
                    entry['live_status'] = 'failed'
                    entry['live_error'] = f'HTTP {exc.code}' if isinstance(exc, HTTPError) else 'Network error'
                    live_stopped = True
        rows = search(db, query['local_query'], raw=query['raw'], limit=20, **filters)
        entry['local_returned'] = len(rows)
        entry['source_text_returned'] = sum(row['content_type'] in ('full_text', 'source_excerpt') for row in rows)
        entry['matches'] = [{k: row[k] for k in ('id', 'title', 'citation', 'url', 'content_type', 'publication', 'excerpt')} for row in rows]
        output['searches'].append(entry)
    with db:
        db.execute('''CREATE TABLE IF NOT EXISTS research_runs
            (id INTEGER PRIMARY KEY, plan TEXT NOT NULL, report TEXT NOT NULL, created_at TEXT NOT NULL)''')
        output['run_id'] = db.execute('INSERT INTO research_runs(plan,report,created_at) VALUES(?,?,?)',
            (json.dumps(plan), json.dumps(output), output['run_at'])).lastrowid
    return output


def render_report(report):
    lines = [f"# {report['title']}", '', report['question'], '', f"Run: {report['run_at']}", '',
             'Local hits measure corpus coverage, not the existence or strength of legal authority.',
             'Search links are prepared queries; they are not searches completed on those services.',
             'Matches in research summaries are researcher wording, not language found in an opinion.', '']
    for entry in report['searches']:
        lines += [f"## {entry['label']}", '', f"Purpose: {entry['purpose']}", '',
                  f"Query: `{entry['query']}`", '',
                  f"Local results: {entry['local_returned']} (maximum 20); actual source text/excerpts: {entry['source_text_returned']}. Live API: {entry['live_status']}.", '']
        if entry.get('live_error'):
            lines += [f"Provider error: {entry['live_error']}. No zero-hit inference is warranted.", '']
        if 'source_records_preserved' in entry:
            lines += [f"Discovery snippets saved: {entry['discovery_imported']}; existing source records preserved: {entry['source_records_preserved']}.", '']
        if 'live_returned' in entry:
            lines += [f"Live results returned within page limit: {entry['live_returned']}.", '']
        for name, url in entry['links'].items():
            lines += [f'- [{name}]({url})']
        lines += ['']
        for match in entry['matches']:
            lines += [f"- {match['id']}: {match['title']} — {match['citation']} ({match['content_type']}, {match['publication']})"]
        lines += ['']
    return '\n'.join(lines)


def passages(record, terms, *, radius=220, limit=10):
    if not terms or any(not t for t in terms):
        raise ValueError('Supply at least one nonempty literal term')
    if not 0 <= radius <= 5000 or not 1 <= limit <= 100:
        raise ValueError('Invalid passage radius or limit')
    text = record['text']
    pattern = re.compile('|'.join(re.escape(t) for t in sorted(terms, key=len, reverse=True)), re.IGNORECASE)
    windows = []
    for match in pattern.finditer(text):
        start, end = max(0, match.start() - radius), min(len(text), match.end() + radius)
        if windows and start <= windows[-1][1]:
            windows[-1][1] = max(windows[-1][1], end)
        else:
            windows.append([start, end])
    return [dict(start=start, end=end, text=text[start:end], content_type=record['content_type'])
            for start, end in windows[:limit]]


def related_queries(record):
    metadata = record.get('metadata', {})
    if isinstance(metadata, str):
        metadata = json.loads(metadata)
    ids = ([metadata['opinion_id']] if metadata.get('opinion_id') else metadata.get('opinion_ids', []))
    if any(not str(i).isdigit() for i in ids):
        raise ValueError('Invalid opinion ID in source metadata')
    queries = []
    for opinion_id in ids:
        q = f'cites:({opinion_id})'
        queries.append(dict(purpose='Find decisions citing this opinion; treatment unclassified',
                            query=q, links={'CourtListener': search_links(q)['CourtListener']}))
    if record.get('citation'):
        bases = []
        for citation in record['citation'].split(';'):
            # Conservative reporter-style normalization: discard trailing year/pinpoint.
            # This is not a universal legal citation parser.
            match = re.match(r'^\s*(\d+\s+[A-Za-z][A-Za-z.\d\s]*?\s+\d+)(?=\s*(?:[,;(]|$))', citation)
            base = match.group(1).strip() if match else citation.strip()
            if base:
                bases.append(base)
        q = ' OR '.join('citation:("' + base.replace('"', '\\"') + '")' for base in bases)
        links = search_links(q)
        links['Google Scholar (case law)'] = search_links(' OR '.join('"' + b + '"' for b in bases))['Google Scholar (case law)']
        queries.append(dict(purpose='Find the cited case by its citation', query=q, links=links))
    q = '"' + record['title'].replace('"', '\\"') + '"'
    queries.append(dict(purpose='Find textual mentions of the case name', query=q, links=search_links(q)))
    return dict(document_id=record['id'], queries=queries,
                cited_opinion_references=metadata.get('opinions_cited', []),
                warning='Citation links do not classify treatment or verify current validity. Confirm publication and read later opinions.')


def import_search_log(db, entries):
    """Record completed external research separately from generated query links.

    Counts are reviewed local source IDs, not the provider's total hit count.
    The log remains a researcher-supplied account of an external search.
    """
    if not isinstance(entries, list):
        raise ValueError('Search log must be a JSON array')
    validated = []
    for entry in entries:
        if any(not isinstance(entry.get(key), str) or not entry[key].strip()
               for key in ('query', 'provider', 'searched_at', 'outcome')):
            raise ValueError('Each search log entry needs query, provider, searched_at and outcome')
        source_ids = entry.get('reviewed_source_ids', [])
        if not isinstance(source_ids, list) or any(not isinstance(i, str) for i in source_ids):
            raise ValueError('reviewed_source_ids must be a list of document IDs')
        for source_id in source_ids:
            if not db.execute('SELECT 1 FROM documents WHERE id=?', (source_id,)).fetchone():
                raise ValueError(f'Unknown reviewed source ID: {source_id}')
        details = dict(entry, count_semantics='reviewed local sources; not provider total hits',
                       record_type='researcher_supplied_external_search_log')
        validated.append((entry['query'], entry['provider'], json.dumps(details), len(set(source_ids)), entry['searched_at']))
    with db:
        for values in validated:
            # Reimporting an identical log should not inflate the search history.
            if not db.execute('SELECT 1 FROM searches WHERE query=? AND provider=? AND filters=? AND result_count=? AND searched_at=?', values).fetchone():
                db.execute('INSERT INTO searches(query,provider,filters,result_count,searched_at) VALUES(?,?,?,?,?)', values)
    return len(validated)
