"""CourtListener discovery. The core remains usable without a service or API key."""
import json
import os
import re
from html import unescape
from html.parser import HTMLParser
from urllib.parse import urlencode, urljoin, urlsplit
from urllib.request import Request, build_opener, HTTPRedirectHandler

BASE = 'https://www.courtlistener.com'


class NoRedirect(HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        return None


def request_json(url):
    # Never forward authorization to a result-supplied URL or a redirect target.
    parsed = urlsplit(url)
    if parsed.scheme != 'https' or parsed.netloc != 'www.courtlistener.com' or not parsed.path.startswith('/api/rest/v4/'):
        raise ValueError('Only the official CourtListener v4 API origin is allowed')
    token = os.environ.get('COURTLISTENER_TOKEN', '').strip()
    if not token:
        raise ValueError('Set COURTLISTENER_TOKEN to use live discovery; links and local search need no key')
    request = Request(url, headers={'Authorization': 'Token ' + token,
                                   'User-Agent': 'OpenCaseLaw/0.1', 'Accept': 'application/json'})
    with build_opener(NoRedirect).open(request, timeout=30) as response:
        return json.load(response)


class TextParser(HTMLParser):
    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.parts = []

    def handle_starttag(self, tag, attrs):
        if tag in ('p', 'div', 'br', 'h1', 'h2', 'h3', 'li', 'tr'):
            self.parts.append('\n')

    def handle_endtag(self, tag):
        if tag in ('p', 'div', 'h1', 'h2', 'h3', 'li', 'tr'):
            self.parts.append('\n')

    def handle_data(self, data):
        self.parts.append(data)


def strip_markup(value):
    parser = TextParser()
    parser.feed(value or '')
    return ''.join(parser.parts).strip()


def discover(query, *, court='', after='', before='', pages=1, fetch=request_json):
    params = {'q': query, 'type': 'o', 'order_by': 'score desc'}
    for key, value in [('court', court), ('filed_after', after), ('filed_before', before)]:
        if value:
            params[key] = value
    url = BASE + '/api/rest/v4/search/?' + urlencode(params)
    records = {}
    for _ in range(pages):
        payload = fetch(url)
        for hit in payload.get('results', []):
            cluster = hit.get('cluster_id')
            if cluster is None:
                continue
            citations = hit.get('citation') or []
            if isinstance(citations, str):
                citations = [citations]
            opinions = hit.get('opinions') or []
            snippet = '\n'.join(strip_markup(o.get('snippet')) for o in opinions).strip()
            record = {
                'id': f'cl:{cluster}', 'title': hit.get('caseNameFull') or hit.get('caseName') or str(cluster),
                'citation': '; '.join(citations), 'court': hit.get('court_id') or hit.get('court', ''),
                'date': hit.get('dateFiled') or '', 'kind': 'opinion',
                'publication': hit.get('status') or 'unknown',
                'url': urljoin(BASE, hit.get('absolute_url') or ''),
                'text': snippet or 'No opinion snippet supplied by provider.', 'content_type': 'snippet',
                'metadata': {'provider': 'CourtListener', 'cluster_id': cluster,
                             'opinion_ids': [o['id'] for o in opinions if o.get('id')],
                             'query': query, 'citation_count': hit.get('citeCount')}
            }
            records[record['id']] = record
        next_url = payload.get('next')
        if not next_url:
            break
        url = urljoin(BASE, next_url)
        parsed = urlsplit(url)
        if parsed.scheme != 'https' or parsed.netloc != 'www.courtlistener.com' or parsed.path != '/api/rest/v4/search/':
            raise ValueError('Provider returned an unexpected pagination URL')
    return list(records.values())


def search_links(query, court=''):
    return {
        'CourtListener': BASE + '/?' + urlencode(dict(q=query, type='o', **({'court': court} if court else {}))),
        'Google Scholar (case law)': 'https://scholar.google.com/scholar?' + urlencode({'q': query, 'as_sdt': '2006'}),
    }


def fetch_opinions(record, fetch=request_json):
    """Import each sub-opinion separately so dissents aren't merged into holdings."""
    metadata = record.get('metadata', {})
    if isinstance(metadata, str):
        metadata = json.loads(metadata)
    ids = metadata.get('opinion_ids', [])
    if not ids:
        raise ValueError('This record has no CourtListener opinion IDs; discover it first or add a text file')
    documents = []
    for opinion_id in ids:
        if not str(opinion_id).isdigit():
            raise ValueError('Invalid CourtListener opinion ID')
        endpoint = f'{BASE}/api/rest/v4/opinions/{opinion_id}/'
        payload = fetch(endpoint)
        text = ''
        field = ''
        for field in ('html_with_citations', 'plain_text', 'html_columbia', 'html_lawbox', 'html_anon_2020', 'html', 'xml_harvard'):
            if payload.get(field):
                text = payload[field].strip() if field == 'plain_text' else strip_markup(payload[field])
                break
        if not text:
            raise ValueError(f'Opinion {opinion_id} has no available text; import a local transcription')
        doc = dict(record)
        opinion_type = payload.get('type') or 'unknown opinion type'
        doc.update(id=f'cl-opinion:{opinion_id}', text=text, content_type='full_text',
                   title=record['title'] + f' [{opinion_type}]')
        doc.pop('sha256', None)
        doc.pop('retrieved_at', None)
        doc['metadata'] = dict(metadata, opinion_id=opinion_id, opinion_type=opinion_type,
                               text_field=field, api_url=endpoint, parent_document_id=record['id'],
                               opinions_cited=payload.get('opinions_cited', []),
                               source_content=payload[field])
        documents.append(doc)
    return documents
