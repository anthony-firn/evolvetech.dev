"""CLI entry point; run python -m caselaw --help."""
import argparse
import json
import os
import sqlite3
import sys
from datetime import date
from pathlib import Path
from urllib.error import HTTPError, URLError

from .citations import citation_graph
from .concordance import concordance
from .compare import compare_sources
from .triage import rank_plan
from .leads import OUTCOMES, import_leads, lead_report, record_attempt
from .providers import discover, fetch_opinions, search_links
from .sources import audit_document, audit_issue, capture_record
from .research import import_search_log, passages, related_queries, render_report, research
from .store import KINDS, POSITIONS, PASSAGE_ROLES, ISSUE_FITS, add_evidence, connect, evidence_matrix, export_issue, import_discovery_records, import_records, now, search


def iso_date(value):
    if not value:
        return value
    try:
        date.fromisoformat(value)
    except ValueError:
        raise argparse.ArgumentTypeError('Use a date in YYYY-MM-DD format')
    return value


def positive(value):
    number = int(value)
    if not 1 <= number <= 100:
        raise argparse.ArgumentTypeError('Use a number between 1 and 100')
    return number


def parser():
    p = argparse.ArgumentParser(description='Open Case Law: search sources, discover opinions, build evidence notebooks.')
    p.add_argument('--db', default=os.environ.get('CASELAW_DB', str(Path.home() / '.local/share/open-case-law/corpus.sqlite')))
    sub = p.add_subparsers(dest='command', required=True)
    sub.add_parser('init', help='Create an empty local database')
    imp = sub.add_parser('import', help='Import a JSON array; reimport updates records by ID')
    imp.add_argument('file', type=Path)
    add = sub.add_parser('add', help='Import UTF-8 opinion, statute, or other source text')
    add.add_argument('file', type=Path)
    add.add_argument('--title', required=True)
    for name in ('citation', 'court', 'jurisdiction', 'url'):
        add.add_argument('--' + name, default='')
    add.add_argument('--date', type=iso_date, default='')
    add.add_argument('--kind', choices=KINDS, default='opinion')
    add.add_argument('--publication', default='unknown')
    add.add_argument('--content-type', choices=('full_text', 'source_excerpt', 'snippet', 'research_summary'), default='full_text')
    capture = sub.add_parser('capture', help='Import a contiguous source excerpt from a line-numbered web capture')
    capture.add_argument('file', type=Path)
    capture.add_argument('--title', required=True)
    capture.add_argument('--url', required=True)
    capture.add_argument('--start-line', type=int, required=True)
    capture.add_argument('--end-line', type=int, required=True)
    for name in ('citation', 'court', 'jurisdiction', 'date'):
        capture.add_argument('--' + name, default='')
    capture.add_argument('--kind', choices=KINDS, default='opinion')
    capture.add_argument('--publication', default='unknown')
    capture.add_argument('--metadata', type=Path, help='Optional researcher-supplied metadata JSON object')
    audit = sub.add_parser('audit', help='Flag source-quality and authority gaps for a document or issue')
    target = audit.add_mutually_exclusive_group(required=True)
    target.add_argument('--document')
    target.add_argument('--issue', type=int)
    s = sub.add_parser('search', help='Rank local text with SQLite BM25')
    s.add_argument('query')
    s.add_argument('--raw', action='store_true', help='Use FTS5 boolean/phrase/NEAR syntax')
    s.add_argument('--mode', choices=('all', 'any'), default='all')
    s.add_argument('--limit', type=positive, default=20)
    for name in ('court', 'jurisdiction', 'publication'):
        s.add_argument('--' + name, default='')
    s.add_argument('--kind', choices=KINDS, default='')
    s.add_argument('--json', action='store_true')
    s.add_argument('--content-type', choices=('full_text', 'source_excerpt', 'snippet', 'research_summary'), default='')
    s.add_argument('--source-only', action='store_true', help='Search source text/excerpts, excluding summaries and discovery snippets')
    live = sub.add_parser('discover', help='Search CourtListener API and save discovery snippets')
    live.add_argument('query')
    live.add_argument('--court', default='', help='CourtListener court ID, e.g. calctapp')
    live.add_argument('--pages', type=positive, default=1)
    for cmd in (s, live):
        cmd.add_argument('--after', type=iso_date, default='')
        cmd.add_argument('--before', type=iso_date, default='')
    links = sub.add_parser('links', help='Generate live search links without an API key')
    links.add_argument('query')
    links.add_argument('--court', default='')
    fetch = sub.add_parser('fetch', help='Download full sub-opinions for a CourtListener discovery result')
    fetch.add_argument('id')
    show = sub.add_parser('show', help='Show source text and provenance as JSON')
    show.add_argument('id')
    compare = sub.add_parser('compare', help='Compare source wording with exact spans; no legal-effect inference')
    compare.add_argument('before')
    compare.add_argument('after')
    compare.add_argument('--limit',type=positive,default=30)
    compare.add_argument('--ignore-case',action='store_true')
    for side in ('before','after'):
        compare.add_argument('--'+side+'-start',type=int,default=0)
        compare.add_argument('--'+side+'-end',type=int)
    compare.add_argument('--output',type=Path)
    issue = sub.add_parser('issue', help='Create or list research questions')
    issue.add_argument('--title')
    issue.add_argument('--question', default='')
    note = sub.add_parser('note', help='Attach assessed evidence to a question')
    note.add_argument('issue', type=int)
    note.add_argument('document')
    note.add_argument('--position', choices=POSITIONS, default='unreviewed')
    note.add_argument('--note', default='')
    note.add_argument('--quote', default='')
    note.add_argument('--pinpoint', default='')
    note.add_argument('--role', choices=PASSAGE_ROLES, default='unclassified')
    note.add_argument('--fit', choices=ISSUE_FITS, default='unassessed')
    matrix = sub.add_parser('matrix', help='Inspect assessed passages, contrary evidence, and authority gaps')
    matrix.add_argument('issue', type=int)
    matrix.add_argument('--output', type=Path)
    export = sub.add_parser('export', help='Export a source-linked Markdown research notebook')
    export.add_argument('issue', type=int)
    export.add_argument('--output', type=Path)
    plan = sub.add_parser('research', help='Run a reusable concept/synonym search plan')
    plan.add_argument('file', type=Path)
    plan.add_argument('--live', action='store_true', help='Execute CourtListener queries; requires API token')
    plan.add_argument('--pages', type=positive, default=1)
    plan.add_argument('--output', type=Path)
    plan.add_argument('--json', action='store_true')
    triage = sub.add_parser('triage', help='Fuse source searches from a plan and expose authority gaps')
    triage.add_argument('file', type=Path)
    triage.add_argument('--limit', type=positive, default=30)
    triage.add_argument('--per-query', type=positive, default=100)
    triage.add_argument('--output', type=Path)
    cites = sub.add_parser('citations', help='Trace outgoing or incoming citations in imported opinion source text')
    cites.add_argument('id')
    cites.add_argument('--direction', choices=('outgoing','incoming'), default='outgoing')
    cites.add_argument('--limit', type=positive, default=50)
    conc = sub.add_parser('concordance', help='Find two to six literal phrases together in source-text passages')
    conc.add_argument('terms', nargs='+')
    conc.add_argument('--window', type=int, default=1200, help='Maximum characters spanning all phrases')
    conc.add_argument('--radius', type=int, default=160)
    conc.add_argument('--limit', type=positive, default=20)
    for name in ('court', 'jurisdiction', 'publication'):
        conc.add_argument('--' + name, default='')
    conc.add_argument('--kind', choices=KINDS, default='')
    related = sub.add_parser('related', help='Prepare citation and citing-case follow-up searches')
    related.add_argument('id')
    passage = sub.add_parser('passages', help='Show literal matching passages with reproducible character offsets')
    passage.add_argument('id')
    passage.add_argument('terms', nargs='+')
    passage.add_argument('--radius', type=int, default=220)
    passage.add_argument('--limit', type=positive, default=10)
    log = sub.add_parser('import-searches', help='Record completed external searches with reviewed-source provenance')
    log.add_argument('file', type=Path)
    lead_import = sub.add_parser('import-leads', help='Import reusable research leads without replacing attempt history')
    lead_import.add_argument('file',type=Path)
    attempt = sub.add_parser('lead-attempt', help='Append a retrieval/review attempt to a research lead')
    attempt.add_argument('id')
    attempt.add_argument('--outcome',choices=OUTCOMES,required=True)
    attempt.add_argument('--note',required=True)
    attempt.add_argument('--query',default='')
    attempt.add_argument('--source',action='append',default=[])
    sub.add_parser('leads', help='Show research priorities, attempt history and source-version changes')
    history = sub.add_parser('history', help='Show search audit trail as JSON')
    history.add_argument('--limit', type=positive, default=20)
    return p


def run(args):
    if args.command == 'links':
        for name, url in search_links(args.query, args.court).items():
            print(f'{name}: {url}')
        return
    with connect(args.db) as db:
        if args.command == 'init':
            print(f'Database ready: {args.db}')
        elif args.command == 'import':
            ids = import_records(db, json.loads(args.file.read_text(encoding='utf-8')))
            print('\n'.join(ids))
        elif args.command == 'add':
            record = {k: getattr(args, k) for k in ('title', 'citation', 'court', 'jurisdiction', 'url', 'date', 'kind', 'publication', 'content_type')}
            record['text'] = args.file.read_text(encoding='utf-8')
            print(import_records(db, [record])[0])
        elif args.command == 'capture':
            metadata = json.loads(args.metadata.read_text(encoding='utf-8')) if args.metadata else {}
            record = capture_record(args.file.read_text(encoding='utf-8'), start=args.start_line, end=args.end_line,
                metadata=metadata, **{k: getattr(args, k) for k in ('title', 'url', 'citation', 'court', 'jurisdiction', 'date', 'kind', 'publication')})
            print(import_records(db, [record])[0])
        elif args.command == 'audit':
            if args.issue:
                report = audit_issue(db, args.issue)
            else:
                row = db.execute('SELECT * FROM documents WHERE id=?', (args.document,)).fetchone()
                if not row:
                    raise ValueError('Unknown document ID')
                report = audit_document(dict(row))
            print(json.dumps(report, ensure_ascii=False, indent=2))
        elif args.command == 'search':
            rows = search(db, args.query, raw=args.raw, mode=args.mode, limit=args.limit,
                          **{k: getattr(args, k) for k in ('court', 'jurisdiction', 'kind', 'publication', 'content_type', 'source_only', 'after', 'before')})
            if args.json:
                print(json.dumps(rows, ensure_ascii=False, indent=2))
            else:
                for row in rows:
                    print(f"{row['id']} | {row['title']} | {row['citation']}")
                    print(f"  {row['date']} | {row['court']} | {row['publication']} | {row['content_type']}")
                    print(f"  {row['excerpt']}\n  {row['url']}\n")
                print(f'{len(rows)} result(s). Ranking measures text relevance, not legal authority.')
        elif args.command == 'discover':
            rows = discover(args.query, court=args.court, after=args.after, before=args.before, pages=args.pages)
            saved = import_discovery_records(db, rows)
            db.execute('INSERT INTO searches(query,provider,filters,result_count,searched_at) VALUES(?,?,?,?,?)',
                       (args.query, 'CourtListener', json.dumps({'court': args.court, 'after': args.after, 'before': args.before, 'pages': args.pages}), len(rows), now()))
            for row in rows:
                print(f"{row['id']} | {row['title']} | {row['citation']}\n  {row['url']}")
            print(f'{len(rows)} discovery result(s). Import full text before quoting. Later treatment not verified.')
            print(f"Preserved {len(saved['preserved_source_ids'])} existing source record(s).")
        elif args.command == 'fetch':
            row = db.execute('SELECT * FROM documents WHERE id=?', (args.id,)).fetchone()
            if not row:
                raise ValueError('Unknown document ID')
            print('\n'.join(import_records(db, fetch_opinions(dict(row)))))
        elif args.command == 'compare':
            result=compare_sources(db,args.before,args.after,limit=args.limit,ignore_case=args.ignore_case,
                **{side+'_'+edge:getattr(args,side+'_'+edge) for side in ('before','after') for edge in ('start','end')})
            rendered=json.dumps(result,ensure_ascii=False,indent=2)
            if args.output:
                args.output.write_text(rendered+'\n',encoding='utf-8')
                print(args.output)
            else:
                print(rendered)
        elif args.command == 'show':
            row = db.execute('SELECT * FROM documents WHERE id=?', (args.id,)).fetchone()
            if not row:
                raise ValueError('Unknown document ID')
            print(json.dumps(dict(row), ensure_ascii=False, indent=2))
        elif args.command == 'issue':
            if args.title:
                print(db.execute('INSERT INTO issues(title,question,created_at) VALUES(?,?,?)',
                                 (args.title, args.question, now())).lastrowid)
            else:
                for row in db.execute('SELECT * FROM issues ORDER BY id'):
                    print(f"{row['id']} | {row['title']}\n  {row['question']}")
        elif args.command == 'note':
            print(add_evidence(db, args.issue, args.document, args.position, args.note, args.quote, args.pinpoint, args.role, args.fit))
        elif args.command == 'matrix':
            report = json.dumps(evidence_matrix(db, args.issue), indent=2, ensure_ascii=False)
            if args.output:
                args.output.write_text(report + '\n', encoding='utf-8')
            else:
                print(report)
        elif args.command == 'export':
            report = export_issue(db, args.issue)
            if args.output:
                args.output.write_text(report + '\n', encoding='utf-8')
                print(args.output)
            else:
                print(report)
        elif args.command == 'triage':
            rendered = json.dumps(rank_plan(db, json.loads(args.file.read_text(encoding='utf-8')), limit=args.limit, per_query=args.per_query), indent=2, ensure_ascii=False)
            if args.output:
                args.output.write_text(rendered + '\n', encoding='utf-8')
                print(args.output)
            else:
                print(rendered)
        elif args.command == 'research':
            report = research(db, json.loads(args.file.read_text(encoding='utf-8')), live=args.live, pages=args.pages)
            rendered = json.dumps(report, ensure_ascii=False, indent=2) if args.json else render_report(report)
            if args.output:
                args.output.write_text(rendered + '\n', encoding='utf-8')
                print(args.output)
            else:
                print(rendered)
        elif args.command == 'import-leads':
            print(import_leads(db,json.loads(args.file.read_text(encoding='utf-8'))))
        elif args.command == 'lead-attempt':
            print(record_attempt(db,args.id,args.outcome,args.note,query=args.query,source_ids=args.source))
        elif args.command == 'leads':
            print(json.dumps(lead_report(db),ensure_ascii=False,indent=2))
        elif args.command == 'citations':
            print(json.dumps(citation_graph(db, args.id, direction=args.direction, limit=args.limit), ensure_ascii=False, indent=2))
        elif args.command == 'concordance':
            result = concordance(db, args.terms, window=args.window, radius=args.radius, limit=args.limit,
                **{k: getattr(args,k) for k in ('court','jurisdiction','publication','kind')})
            print(json.dumps(result, ensure_ascii=False, indent=2))
        elif args.command in ('related', 'passages'):
            row = db.execute('SELECT * FROM documents WHERE id=?', (args.id,)).fetchone()
            if not row:
                raise ValueError('Unknown document ID')
            result = related_queries(dict(row)) if args.command == 'related' else passages(
                dict(row), args.terms, radius=args.radius, limit=args.limit)
            print(json.dumps(result, ensure_ascii=False, indent=2))
        elif args.command == 'import-searches':
            print(f"Validated {import_search_log(db, json.loads(args.file.read_text(encoding='utf-8')))} external search record(s).")
        elif args.command == 'history':
            print(json.dumps([dict(r) for r in db.execute('SELECT * FROM searches ORDER BY id DESC LIMIT ?',
                                                       (args.limit,))], ensure_ascii=False, indent=2))


def main():
    args = parser().parse_args()
    try:
        run(args)
    except HTTPError as exc:
        # Do not print response headers, request objects, or credentials.
        print(f'CourtListener HTTP {exc.code}. Check token/access (401/403) or retry later (429).', file=sys.stderr)
        raise SystemExit(1)
    except URLError:
        print('Cannot reach CourtListener. Local search and imports remain available.', file=sys.stderr)
        raise SystemExit(1)
    except (OSError, ValueError, sqlite3.Error, TypeError, KeyError) as exc:
        print(f'Error: {exc}', file=sys.stderr)
        raise SystemExit(1)
