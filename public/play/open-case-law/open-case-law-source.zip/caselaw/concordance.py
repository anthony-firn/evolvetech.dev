"""Find literal phrases together in bounded passages of source text."""
from collections import Counter
from itertools import islice
import re
from .sources import audit_document
from .store import search


def concordance(db, terms, *, window=1200, radius=160, limit=20, document_limit=200, **filters):
    if (not isinstance(terms, list) or not 2 <= len(terms) <= 6
            or any(not isinstance(t, str) or not t.strip() or len(t) > 200 or not re.search(r'\w', t) for t in terms)):
        raise ValueError('Use two to six nonempty literal phrases of at most 200 characters')
    terms = [t.strip() for t in terms]
    if len({' '.join(t.casefold().split()) for t in terms}) != len(terms):
        raise ValueError('Use distinct phrases')
    if not 1 <= window <= 10000 or not 0 <= radius <= 2000 or not 1 <= limit <= 100 or not 1 <= document_limit <= 1000:
        raise ValueError('Invalid concordance window, context radius, result limit, or document limit')
    # Candidate retrieval is broad; literal verification below determines passages.
    query = ' AND '.join('"' + t.replace('"', '""') + '"' for t in terms)
    filters = dict(filters, source_only=True)
    candidates = search(db, query, raw=True, limit=document_limit+1, **filters)
    patterns = [re.compile(r'(?<!\w)' + r'\s+'.join(re.escape(w) for w in t.split()) + r'(?!\w)', re.I) for t in terms]
    results, capped = [], []
    for doc in candidates[:document_limit]:
        review = audit_document(dict(doc))
        occurrences = []
        for group, pattern in enumerate(patterns):
            matches = list(islice(pattern.finditer(doc['text']), 5001))
            if len(matches) > 5000:
                capped.append(doc['id'])
            occurrences.extend((m.start(), m.end(), group) for m in matches[:5000])
        occurrences.sort()
        counts, left = Counter(), 0
        for right, occurrence in enumerate(occurrences):
            counts[occurrence[2]] += 1
            if len(counts) != len(terms):
                continue
            while counts[occurrences[left][2]] > 1:
                counts[occurrences[left][2]] -= 1
                left += 1
            matched = occurrences[left:right+1]
            start, end = matched[0][0], max(m[1] for m in matched)
            if end-start <= window:
                context_start, context_end = max(0,start-radius), min(len(doc['text']),end+radius)
                results.append(dict(document_id=doc['id'], title=doc['title'], citation=doc['citation'],
                    url=doc['url'], publication=doc['publication'], kind=doc['kind'], content_type=doc['content_type'],
                    source_sha256=doc['sha256'], start=start, end=end,
                    source_authority=review['authority'], review_flags=review['flags'],
                    context_start=context_start, context_end=context_end, context=doc['text'][context_start:context_end],
                    matches=[dict(term=terms[g], start=a, end=b, text=doc['text'][a:b]) for a,b,g in matched]))
                if len(results) > limit:
                    break
            counts[occurrences[left][2]] -= 1
            if not counts[occurrences[left][2]]:
                del counts[occurrences[left][2]]
            left += 1
        if len(results) > limit:
            break
    return dict(terms=terms, window_characters=window, passages=results[:limit],
        candidate_documents=min(len(candidates),document_limit),
        candidate_limit_reached=len(candidates)>document_limit,
        passage_limit_reached=len(results)>limit, occurrence_capped_documents=sorted(set(capped)),
        warning='Bounded local source-text search only. Phrases must occur together within the selected character window; case and whitespace are ignored. Summaries/snippets are excluded. Proximity does not establish a holding, endorsement, or direct relevance. Missing passages do not establish absence of authority.')
