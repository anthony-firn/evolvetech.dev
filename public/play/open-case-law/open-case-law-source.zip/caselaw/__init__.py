"""General-purpose legal research tools. No topic-specific search rules."""
