"""Persistent research leads and append-only retrieval/review attempts."""
import json
from .store import now

OUTCOMES = ('retrieved','reviewed','unavailable','no_relevant_result','pending_follow_up')


def initialize(db):
    db.executescript('''
        CREATE TABLE IF NOT EXISTS research_leads (
            id TEXT PRIMARY KEY, title TEXT NOT NULL, question TEXT NOT NULL,
            url TEXT NOT NULL, priority INTEGER NOT NULL, created_at TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS lead_attempts (
            id INTEGER PRIMARY KEY, lead_id TEXT NOT NULL REFERENCES research_leads(id),
            outcome TEXT NOT NULL, note TEXT NOT NULL, query TEXT NOT NULL,
            source_versions TEXT NOT NULL, attempted_at TEXT NOT NULL
        );
    ''')


def import_leads(db, records):
    if not isinstance(records,list):
        raise ValueError('Lead import requires an array')
    initialize(db)
    with db:
        for record in records:
            if not isinstance(record,dict) or any(not isinstance(record.get(k),str) or not record[k].strip() for k in ('id','title','question')):
                raise ValueError('Each lead requires a nonempty ID, title and research question')
            priority=record.get('priority',3)
            if type(priority) is not int or not 1 <= priority <= 5:
                raise ValueError('Lead priority must be an integer from 1 (highest) to 5')
            url=record.get('url','')
            if not isinstance(url,str):
                raise ValueError('Lead URL must be text')
            db.execute('''INSERT INTO research_leads VALUES(?,?,?,?,?,?)
                ON CONFLICT(id) DO UPDATE SET title=excluded.title, question=excluded.question,
                url=excluded.url, priority=excluded.priority''',
                (record['id'],record['title'],record['question'],url,priority,now()))
    return len(records)


def record_attempt(db, lead_id, outcome, note, *, query='', source_ids=None):
    initialize(db)
    if not db.execute('SELECT id FROM research_leads WHERE id=?',(lead_id,)).fetchone():
        raise ValueError('Unknown research lead')
    if outcome not in OUTCOMES or not isinstance(note,str) or not note.strip():
        raise ValueError('A supported retrieval/review outcome and nonempty note are required')
    if not isinstance(query,str):
        raise ValueError('Attempt query must be text')
    source_ids=[] if source_ids is None else source_ids
    if not isinstance(source_ids,list) or any(not isinstance(s,str) for s in source_ids):
        raise ValueError('Attempt sources must be a list of document IDs')
    versions=[]
    for identity in dict.fromkeys(source_ids):
        row=db.execute('SELECT id,sha256,content_type,title,url,publication,kind,court,jurisdiction,date,metadata FROM documents WHERE id=?',(identity,)).fetchone()
        if not row:
            raise ValueError('Unknown attempt source: '+identity)
        source=dict(row)
        source['authority']=json.loads(source.pop('metadata')).get('authority',{})
        versions.append(source)
    if outcome in ('retrieved','reviewed') and not versions:
        raise ValueError('Retrieved/reviewed attempts require an imported source')
    with db:
        return db.execute('INSERT INTO lead_attempts(lead_id,outcome,note,query,source_versions,attempted_at) VALUES(?,?,?,?,?,?)',
            (lead_id,outcome,note,query,json.dumps(versions),now())).lastrowid


def lead_report(db):
    initialize(db)
    result=[]
    for lead in db.execute('SELECT * FROM research_leads ORDER BY priority,id').fetchall():
        attempts=[]
        for row in db.execute('SELECT * FROM lead_attempts WHERE lead_id=? ORDER BY id',(lead['id'],)).fetchall():
            attempt=dict(row)
            attempt['sources']=json.loads(attempt.pop('source_versions'))
            for source in attempt['sources']:
                current=db.execute('SELECT * FROM documents WHERE id=?',(source['id'],)).fetchone()
                source['authority_snapshot_available']='authority' in source
                source['authority_changed']=None
                if current and source['authority_snapshot_available']:
                    authority=json.loads(current['metadata']).get('authority',{})
                    source['authority_changed']=authority!=source['authority'] or any(
                        current[k]!=source[k] for k in ('publication','kind','court','jurisdiction','date'))
                source['source_changed']=not current or current['sha256']!=source['sha256'] or current['content_type']!=source['content_type'] or source['authority_changed'] is True
            attempts.append(attempt)
        result.append(dict(lead,latest_outcome=attempts[-1]['outcome'] if attempts else 'unattempted',attempts=attempts))
    return dict(leads=result,warning='Outcomes record retrieval/review activity, not legal conclusions. Unavailable or no-relevant-result attempts do not prove absence of authority. Reviewed sources may be adverse, historical, tentative, or unrelated. Source versions retain hashes and metadata, not frozen full text; evidence notebooks preserve quoted source snapshots.')
