/** Dependency-free local server: node server/dev.mjs [port] [static root] */
import {createServer} from 'node:http';
import {readFile} from 'node:fs/promises';
import {resolve,extname} from 'node:path';
import handler from './search.mjs';
const root=resolve(process.argv[3]||new URL('../web',import.meta.url).pathname);
const types={'.html':'text/html','.mjs':'text/javascript','.css':'text/css','.zip':'application/zip','.json':'application/json'};
createServer(async(req,res)=>{
  try{
    const url=new URL(req.url,'http://localhost');
    if(url.pathname==='/api/case-law/search'){
      const result=await handler(new Request(url,{method:req.method,headers:req.headers}));res.writeHead(result.status,Object.fromEntries(result.headers));res.end(Buffer.from(await result.arrayBuffer()));return;
    }
    const path=resolve(root,'.'+decodeURIComponent(url.pathname)+(url.pathname.endsWith('/')?'index.html':''));
    if(!path.startsWith(root+'/')){res.writeHead(403);res.end();return;}
    const data=await readFile(path);res.writeHead(200,{'Content-Type':types[extname(path)]||'text/plain'});res.end(data);
  }catch{res.writeHead(404);res.end('Not found');}
}).listen(Number(process.argv[2]||8080),'127.0.0.1',()=>console.log('Open Case Law: http://127.0.0.1:'+Number(process.argv[2]||8080)));
