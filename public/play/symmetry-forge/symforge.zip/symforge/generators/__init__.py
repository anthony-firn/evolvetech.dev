"""Candidate generators."""
