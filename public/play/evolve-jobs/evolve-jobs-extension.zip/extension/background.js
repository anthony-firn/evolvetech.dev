// src/core.js
var matcher = { contains: (text, term) => text.includes(term), salaryMeets: (min, floor) => Number.isFinite(min) && min > 0 && min >= floor };
function setMatcher(engine) {
  matcher = engine;
}
var slug = /^[a-zA-Z0-9_-]{1,100}$/;
function boardURL(board) {
  if (!slug.test(board)) throw new Error("Invalid Lever board name");
  return `https://api.lever.co/v0/postings/${board}?mode=json`;
}
function normalize(board, post, now = Date.now()) {
  boardURL(board);
  if (!/^[a-zA-Z0-9-]{1,100}$/.test(post.id)) throw new Error("Invalid posting ID");
  const salary = post.salaryRange || {};
  const annual = ["per-year", "per-year-salary"].includes(salary.interval);
  return {
    version: 1,
    id: `lever:${board}:${post.id}`,
    provider: "lever",
    board,
    postingId: post.id,
    title: String(post.text || "").slice(0, 300),
    company: board,
    location: String(post.categories?.location || "").slice(0, 300),
    remote: post.workplaceType === "remote",
    description: [post.descriptionPlain, ...(post.lists || []).map((x) => x.content?.replace(/<[^>]*>/g, " ")), post.additionalPlain].filter(Boolean).join("\n").slice(0, 5e4),
    salaryMin: annual && Number.isFinite(salary.min) && salary.min > 0 ? salary.min : null,
    salaryMax: annual && Number.isFinite(salary.max) && salary.max > 0 ? salary.max : null,
    currency: annual ? salary.currency : null,
    url: `https://jobs.lever.co/${board}/${post.id}`,
    applyUrl: `https://jobs.lever.co/${board}/${post.id}/apply`,
    fetchedAt: now
  };
}
async function discover(board, request = fetch) {
  const res = await request(boardURL(board), { signal: AbortSignal.timeout(2e4), redirect: "error" });
  if (!res.ok) throw new Error(`Lever ${board}: HTTP ${res.status}`);
  const rows = await res.json();
  if (!Array.isArray(rows) || rows.length > 2e4) throw new Error("Invalid board response");
  return rows.map((row) => normalize(board, row));
}
function validatePolicy(p) {
  if (!Number.isFinite(p.minAnnual) || p.minAnnual <= 0 || !/^[A-Z]{3}$/.test(p.currency || "")) throw new Error("Set a positive annual pay floor and ISO currency");
  for (const key of ["titleTerms", "requiredTerms", "excludedTerms", "locations"]) {
    if (!Array.isArray(p[key]) || p[key].some((x) => typeof x !== "string" || !x.trim())) throw new Error(`Invalid ${key}`);
  }
  if (!p.titleTerms.length || !p.requiredTerms.length || !p.remoteOnly && !p.locations.length) throw new Error("Set role, qualification and location rules");
  return p;
}
function assess(job, policy, now = Date.now()) {
  validatePolicy(policy);
  const reasons = [];
  const text = `${job.title}
${job.description}`.toLowerCase();
  if (!Number.isFinite(job.fetchedAt) || now - job.fetchedAt > 864e5 || job.fetchedAt > now + 3e5) reasons.push("Listing must be refreshed");
  if (!matcher.salaryMeets(job.salaryMin ?? NaN, policy.minAnnual) || job.currency !== policy.currency) reasons.push("Annual salary floor or currency not confirmed");
  if (!policy.titleTerms.some((x) => matcher.contains(job.title.toLowerCase(), x.toLowerCase()))) reasons.push("Role does not match");
  if (!policy.requiredTerms.every((x) => matcher.contains(text, x.toLowerCase()))) reasons.push("Qualification keywords missing");
  if (policy.excludedTerms.some((x) => matcher.contains(text, x.toLowerCase()))) reasons.push("Excluded terms present");
  if (policy.remoteOnly && !job.remote) reasons.push("Remote work not confirmed");
  if (policy.locations.length && !policy.locations.some((x) => matcher.contains(job.location.toLowerCase(), x.toLowerCase()))) reasons.push("Location does not match");
  return { eligible: reasons.length === 0, reasons };
}
function publicJob(job) {
  return Object.fromEntries(["version", "id", "provider", "board", "postingId", "title", "company", "location", "remote", "description", "salaryMin", "salaryMax", "currency", "url", "applyUrl", "fetchedAt"].map((k) => [k, job[k]]));
}
function parsePublicJob(raw) {
  if (!raw || raw.version !== 1 || raw.provider !== "lever") throw new Error("Unsupported listing");
  boardURL(raw.board);
  if (!/^[a-zA-Z0-9-]{1,100}$/.test(raw.postingId) || raw.id !== `lever:${raw.board}:${raw.postingId}`) throw new Error("Invalid listing identity");
  for (const key of ["title", "description", "location", "company"]) if (typeof raw[key] !== "string" || raw[key].length > 5e4) throw new Error("Invalid listing text");
  if (typeof raw.remote !== "boolean" || !Number.isFinite(raw.fetchedAt)) throw new Error("Invalid listing metadata");
  for (const key of ["salaryMin", "salaryMax"]) if (raw[key] !== null && (!Number.isFinite(raw[key]) || raw[key] <= 0)) throw new Error("Invalid pay");
  if (raw.currency !== null && !/^[A-Z]{3}$/.test(raw.currency)) throw new Error("Invalid currency");
  const clean = publicJob(raw);
  clean.url = `https://jobs.lever.co/${raw.board}/${raw.postingId}`;
  clean.applyUrl = `${clean.url}/apply`;
  return clean;
}

// src/wasm.js
async function loadMatcher(url) {
  const res = await fetch(url);
  if (!res.ok) throw new Error("WASM matching engine unavailable");
  const { instance } = await WebAssembly.instantiate(await res.arrayBuffer());
  const wasm = instance.exports, encoder = new TextEncoder();
  function contains(text, term) {
    const h = encoder.encode(text), n = encoder.encode(term), hp = wasm.alloc(h.length), np = wasm.alloc(n.length);
    try {
      new Uint8Array(wasm.memory.buffer, hp, h.length).set(h);
      new Uint8Array(wasm.memory.buffer, np, n.length).set(n);
      return wasm.contains(hp, h.length, np, n.length) === 1;
    } finally {
      wasm.dealloc(hp, h.length);
      wasm.dealloc(np, n.length);
    }
  }
  return { contains, salaryMeets: (min, floor) => wasm.salary_meets(min, floor) === 1 };
}

// extension/background.js
var ready = loadMatcher(chrome.runtime.getURL("matcher.wasm")).then(setMatcher);
var serial = Promise.resolve();
function locked(fn) {
  const next = serial.then(fn);
  serial = next.catch(() => {
  });
  return next;
}
var empty = () => ({ running: false, history: [], active: null });
function validate(s) {
  validatePolicy(s.plan.policy);
  if (!s.truthful || !s.profile.name.trim() || !s.profile.email.includes("@") || !s.profile.resume?.data || !s.employers.length || !Number.isInteger(s.maxPerDay) || s.maxPerDay < 1 || s.maxPerDay > 25) throw new Error("Set a truthful profile, r\xE9sum\xE9, employers and daily attempt limit");
  s.plan.jobs = s.plan.jobs.map(parsePublicJob);
}
async function advance() {
  await ready;
  const data = await chrome.storage.local.get(["state", "settings"]), state = data.state || empty(), s = data.settings;
  if (!state.running || !s) return;
  if (state.active) {
    const active = state.history.find((x) => x.id === state.active);
    if (Date.now() - active.at < 3e5) return;
    active.status = "uncertain";
    active.note = "Interrupted or timed out; check employer before any retry";
    state.active = null;
    await chrome.storage.local.set({ state });
  }
  validate(s);
  const day = (/* @__PURE__ */ new Date()).toISOString().slice(0, 10);
  if (state.history.filter((x) => new Date(x.at).toISOString().slice(0, 10) === day).length >= s.maxPerDay) {
    state.running = false;
    await chrome.storage.local.set({ state });
    return;
  }
  for (const candidate of s.plan.jobs) {
    if (!s.employers.includes(candidate.board) || state.history.some((x) => x.id === candidate.id)) continue;
    let live;
    try {
      live = (await discover(candidate.board)).find((x) => x.id === candidate.id);
    } catch (error) {
      state.note = error.message;
      await chrome.storage.local.set({ state });
      return;
    }
    if (!live || !assess(live, s.plan.policy).eligible) continue;
    const entry = { id: live.id, url: live.applyUrl, at: Date.now(), status: "reserved" };
    state.history.push(entry);
    state.active = entry.id;
    await chrome.storage.local.set({ state });
    try {
      const tab = await chrome.tabs.create({ url: "about:blank", active: false });
      entry.tab = tab.id;
      await chrome.storage.local.set({ state });
      await chrome.tabs.update(tab.id, { url: live.applyUrl });
    } catch (error) {
      entry.status = "needs-review";
      entry.note = error.message;
      state.active = null;
      await chrome.storage.local.set({ state });
    }
    return;
  }
  state.running = false;
  state.note = "No unattempted matching roles remain";
  await chrome.storage.local.set({ state });
}
async function handle(message, sender) {
  const data = await chrome.storage.local.get(["settings", "state"]), state = data.state || empty();
  const ownPanel = sender.url === chrome.runtime.getURL("panel.html");
  if (["save", "start", "stop", "clear"].includes(message.type)) {
    if (!ownPanel) throw new Error("Open the extension panel");
    if (message.type === "save") {
      if (state.active) throw new Error("Wait for the current application to finish before editing settings");
      validate(message.settings);
      await chrome.storage.local.set({ settings: message.settings });
      return { message: "Saved" };
    }
    if (message.type === "clear") {
      if (state.active) throw new Error("Close the active employer tab before deleting the profile");
      state.running = false;
      await chrome.storage.local.set({ state });
      await chrome.storage.local.remove("settings");
      return { message: "Profile and r\xE9sum\xE9 deleted; application history retained for duplicate protection" };
    }
    if (message.type === "start") {
      if (!data.settings) throw new Error("Save your configuration first");
      validate(data.settings);
      state.running = true;
      await chrome.alarms.create("advance", { periodInMinutes: 1 });
    }
    if (message.type === "stop") state.running = false;
    await chrome.storage.local.set({ state });
    if (message.type === "start") queueMicrotask(() => locked(advance));
    return { message: message.type === "stop" ? "Queue stopped; the current application may already be in progress. Close its employer tab to interrupt it." : "Queue started. Check history for results." };
  }
  const entry = state.history.find((x) => x.id === state.active);
  const senderURL = sender.url ? new URL(sender.url) : null;
  const expected = entry ? new URL(entry.url) : null;
  const applicationPage = expected && senderURL?.origin === expected.origin && senderURL.pathname === expected.pathname;
  const thanksPage = expected && senderURL?.origin === expected.origin && senderURL.pathname === expected.pathname.replace(/\/apply$/, "/thanks");
  if (!entry || entry.tab !== sender.tab?.id || !(applicationPage || message.type === "result" && thanksPage && entry.status === "submitting")) throw new Error("No authorized application for this tab");
  if (message.type === "ready") {
    if (entry.status !== "reserved") throw new Error("This application was already started; inspect history");
    if (!state.running) throw new Error("Queue stopped");
    entry.status = "filling";
    await chrome.storage.local.set({ state });
    return { profile: data.settings.profile };
  }
  if (message.type === "submitting") {
    if (!state.running || entry.status !== "filling") throw new Error("Submission is not authorized");
    entry.status = "submitting";
    entry.note = "May have been sent; do not retry automatically";
    await chrome.storage.local.set({ state });
    return { ok: true };
  }
  if (message.type === "result") {
    if (!["filling", "submitting"].includes(entry.status)) throw new Error("Unexpected application state");
    entry.status = message.success && entry.status === "submitting" ? "submitted" : entry.status === "submitting" ? "uncertain" : "needs-review";
    entry.note = String(message.note || "").slice(0, 500);
    state.active = null;
    await chrome.storage.local.set({ state });
    queueMicrotask(() => locked(advance));
    return { ok: true };
  }
  throw new Error("Unknown message");
}
chrome.runtime.onMessage.addListener((msg, sender, reply) => {
  locked(() => handle(msg, sender)).then(reply, (e) => reply({ error: e.message }));
  return true;
});
chrome.alarms.onAlarm.addListener(() => locked(advance).catch(console.error));
chrome.action.onClicked.addListener(() => chrome.tabs.create({ url: chrome.runtime.getURL("panel.html") }));
chrome.tabs.onRemoved.addListener((tabId) => locked(async () => {
  const { state } = await chrome.storage.local.get("state");
  const entry = state?.history.find((x) => x.id === state.active && x.tab === tabId);
  if (entry) {
    entry.status = ["submitting", "filling"].includes(entry.status) ? "uncertain" : "needs-review";
    entry.note = "Employer tab closed; check for submission";
    state.active = null;
    await chrome.storage.local.set({ state });
    await advance();
  }
}));
