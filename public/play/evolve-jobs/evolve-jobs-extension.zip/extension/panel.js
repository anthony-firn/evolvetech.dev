// src/core.js
var slug = /^[a-zA-Z0-9_-]{1,100}$/;
function boardURL(board) {
  if (!slug.test(board)) throw new Error("Invalid Lever board name");
  return `https://api.lever.co/v0/postings/${board}?mode=json`;
}
function validatePolicy(p) {
  if (!Number.isFinite(p.minAnnual) || p.minAnnual <= 0 || !/^[A-Z]{3}$/.test(p.currency || "")) throw new Error("Set a positive annual pay floor and ISO currency");
  for (const key of ["titleTerms", "requiredTerms", "excludedTerms", "locations"]) {
    if (!Array.isArray(p[key]) || p[key].some((x) => typeof x !== "string" || !x.trim())) throw new Error(`Invalid ${key}`);
  }
  if (!p.titleTerms.length || !p.requiredTerms.length || !p.remoteOnly && !p.locations.length) throw new Error("Set role, qualification and location rules");
  return p;
}
function publicJob(job) {
  return Object.fromEntries(["version", "id", "provider", "board", "postingId", "title", "company", "location", "remote", "description", "salaryMin", "salaryMax", "currency", "url", "applyUrl", "fetchedAt"].map((k) => [k, job[k]]));
}
function parsePublicJob(raw) {
  if (!raw || raw.version !== 1 || raw.provider !== "lever") throw new Error("Unsupported listing");
  boardURL(raw.board);
  if (!/^[a-zA-Z0-9-]{1,100}$/.test(raw.postingId) || raw.id !== `lever:${raw.board}:${raw.postingId}`) throw new Error("Invalid listing identity");
  for (const key of ["title", "description", "location", "company"]) if (typeof raw[key] !== "string" || raw[key].length > 5e4) throw new Error("Invalid listing text");
  if (typeof raw.remote !== "boolean" || !Number.isFinite(raw.fetchedAt)) throw new Error("Invalid listing metadata");
  for (const key of ["salaryMin", "salaryMax"]) if (raw[key] !== null && (!Number.isFinite(raw[key]) || raw[key] <= 0)) throw new Error("Invalid pay");
  if (raw.currency !== null && !/^[A-Z]{3}$/.test(raw.currency)) throw new Error("Invalid currency");
  const clean = publicJob(raw);
  clean.url = `https://jobs.lever.co/${raw.board}/${raw.postingId}`;
  clean.applyUrl = `${clean.url}/apply`;
  return clean;
}

// extension/panel.js
var $ = (s) => document.querySelector(s);
var form = $("#settings");
var plan;
var resume;
var { settings } = await chrome.storage.local.get("settings");
if (settings) {
  plan = settings.plan;
  resume = settings.profile.resume;
  for (const key of ["name", "email", "phone", "currentCompany"]) form.elements[key].value = settings.profile[key] || "";
  form.elements.answers.value = JSON.stringify(settings.profile.answers || {}, null, 2);
  form.elements.employers.value = settings.employers.join(", ");
  form.elements.maxPerDay.value = settings.maxPerDay;
}
function message(t) {
  $("#status").textContent = t;
}
async function refresh() {
  const { state } = await chrome.storage.local.get("state");
  $("#history").textContent = JSON.stringify(state || { history: [], running: false }, null, 2);
}
chrome.storage.onChanged.addListener(refresh);
await refresh();
$("#plan").addEventListener("change", async (event) => {
  try {
    const file = event.target.files[0];
    if (!file) return;
    if (file.size > 5e6) throw new Error("Plan must be under 5 MB");
    const data = JSON.parse(await file.text());
    validatePolicy(data.policy);
    if (data.version !== 1 || !Array.isArray(data.jobs) || data.jobs.length > 5e3) throw new Error("Invalid application plan");
    plan = { version: 1, policy: data.policy, jobs: data.jobs.map(parsePublicJob) };
    message(`Loaded ${plan.jobs.length} listings. Save locally to confirm.`);
  } catch (e) {
    message(e.message);
  }
});
$("#resume").addEventListener("change", async (event) => {
  try {
    const file = event.target.files[0];
    if (!file) return;
    if (file.size > 2e6 || !file.name.toLowerCase().endsWith(".pdf")) throw new Error("Choose a PDF under 2 MB");
    const bytes = new Uint8Array(await file.arrayBuffer());
    if (new TextDecoder().decode(bytes.slice(0, 5)) !== "%PDF-") throw new Error("Expected a PDF file");
    let binary = "";
    for (const byte of bytes) binary += String.fromCharCode(byte);
    resume = { name: file.name, data: btoa(binary), type: "application/pdf" };
    message("R\xE9sum\xE9 loaded in memory; save locally to keep it.");
  } catch (e) {
    message(e.message);
  }
});
form.addEventListener("submit", async (event) => {
  event.preventDefault();
  try {
    if (!plan || !resume) throw new Error("Import an application plan and a r\xE9sum\xE9 first");
    const f = new FormData(form), answers = JSON.parse(f.get("answers"));
    if (!answers || Array.isArray(answers) || typeof answers !== "object" || Object.values(answers).some((x) => typeof x !== "string")) throw new Error("Answers must be an object of exact labels to string answers");
    const employers = f.get("employers").split(",").map((x) => x.trim()).filter(Boolean);
    if (!employers.length) throw new Error("Enable at least one employer");
    const settings2 = { plan, employers, maxPerDay: Number(f.get("maxPerDay")), truthful: f.has("truthful"), profile: { name: f.get("name"), email: f.get("email"), phone: f.get("phone"), currentCompany: f.get("currentCompany"), answers, resume } };
    const result = await chrome.runtime.sendMessage({ type: "save", settings: settings2 });
    if (result.error) throw new Error(result.error);
    message("Profile and r\xE9sum\xE9 saved only in this extension\u2019s local browser storage.");
  } catch (e) {
    message(e.message);
  }
});
for (const [id, type] of [["start", "start"], ["stop", "stop"], ["clear", "clear"]]) $("#" + id).addEventListener("click", async () => {
  const result = await chrome.runtime.sendMessage({ type });
  message(result.error || result.message);
  if (type === "clear") {
    resume = void 0;
    form.reset();
  }
});
