import { LARGE, MODELS, cacheKey, formatBytes, hfUrl, listRepo, parseHfReference, resolveParts, splitParts } from './models.js';
import { renderMarkdown, splitThinking } from './markdown.js';
import { stripToolCalls } from './tools.js';
import { wantsDevelopment, wantsSnakeStarter, wantsBrowser, developmentSummary, createDevelopmentView } from './chat-development.mjs';

const $ = (id) => document.getElementById(id);
const app = $('app');
let worker = new Worker(new URL('./worker.js', import.meta.url), { type: 'module' });

const DEFAULTS = { system: '', temperature: 0.7, top_p: 0.95, top_k: 40, min_p: 0.05, repeat_penalty: 1.1, maxTokens: 1024, ctx: 4096, thinking: true, gpu: 'high-performance', gpuMemory: 'auto', internet: false, jinaKey: '' };
const SUGGESTIONS = [
  'Make me a Snake game I can play.',
  'Write a haiku about running AI on my own laptop.',
  'Give me three tips for writing clear Rust code.',
  'Plan a relaxed weekend in Lisbon in five bullet points.',
];

const state = {
  phase: 'starting', // starting | idle | loading | ready | generating | preparing | agent
  adapter: null,
  cache: { models: [], supported: true },
  loading: null, // { label, id, key }
  loaded: null, // { id, key, label, info, chat }
  messages: [], // { role, content, stats?, error? }
  developmentActive: false,
  live: null, // the assistant message being written
  settings: loadSettings(),
};

function loadSettings() {
  try {
    return { ...DEFAULTS, ...JSON.parse(localStorage.getItem('evolve-llm-settings') || '{}') };
  } catch {
    return { ...DEFAULTS };
  }
}

function saveSettings() {
  try { localStorage.setItem('evolve-llm-settings', JSON.stringify(state.settings)); } catch { /* storage unavailable */ }
}

function remember(key, value) {
  try { localStorage.setItem(key, value); } catch { /* storage unavailable */ }
}

function recall(key) {
  try { return localStorage.getItem(key); } catch { return null; }
}

function el(tag, attrs = {}, ...children) {
  const node = document.createElement(tag);
  for (const [k, v] of Object.entries(attrs)) {
    if (v === undefined || v === null || v === false) continue;
    if (k === 'class') node.className = v;
    else if (k === 'text') node.textContent = v;
    else if (k.startsWith('on')) node.addEventListener(k.slice(2), v);
    else node.setAttribute(k, v === true ? '' : v);
  }
  node.append(...children.filter((c) => c !== null && c !== undefined && c !== false));
  return node;
}

function setPhase(phase) {
  state.phase = phase;
  app.dataset.phase = phase;
  const ready = phase === 'ready';
  const agentBusy = phase === 'agent' || phase === 'preparing';
  const generating = phase === 'generating' || (agentBusy && Boolean(state.live?.development));
  $('chat-mode').disabled = agentBusy || phase === 'generating';
  $('file-input').disabled = agentBusy;
  $('hf-input').disabled = agentBusy;
  $('prompt').disabled = !(ready || phase === 'generating');
  $('prompt').placeholder = state.loaded ? 'Ask a question or build…' : 'Choose a model to start';
  $('send').disabled = !ready;
  $('send').hidden = generating;
  $('stop').hidden = !generating;
  $('new-chat').disabled = !(ready && state.messages.length);
  $('welcome').hidden = Boolean(state.loaded) || phase === 'loading';
  $('loading').hidden = phase !== 'loading';
  $('ready').hidden = !(state.loaded && !state.messages.length && phase !== 'loading');
  renderModels();
}

// ---- GPU status ----

function describeGpu(a) {
  const parts = [a.description, [a.vendor, a.architecture].filter(Boolean).join(' ')].filter(Boolean);
  return parts[0] ? `${parts[0]} · WebGPU` : 'WebGPU ready';
}

function showGpu(adapter) {
  state.adapter = adapter;
  const chip = $('gpu-chip');
  const notice = $('gpu-notice');
  notice.replaceChildren();
  if (!adapter.ok) {
    chip.dataset.state = 'error';
    $('gpu-name').textContent = 'WebGPU unavailable';
    notice.className = 'notice error';
    notice.append(
      el('h2', { text: adapter.reason === 'no-webgpu' ? 'This browser does not offer WebGPU' : 'No GPU adapter is available' }),
      el('p', { text: 'Evolve LLM needs WebGPU to run models on your graphics processor. Try one of these:' }),
      el('ul', {},
        el('li', { text: 'Chrome or Edge 113 or later on Windows, macOS, ChromeOS or Android.' }),
        el('li', { text: 'Safari 26 or later on macOS, iOS or iPadOS.' }),
        el('li', { text: 'Firefox 141 or later on Windows.' }),
        el('li', {}, 'On Linux, Chrome may need ', el('code', { text: 'chrome://flags/#enable-unsafe-webgpu' }), ' and the Vulkan flag. Updated GPU drivers help.'),
      ),
    );
    notice.hidden = false;
    $('start-recommended').hidden = true;
    return;
  }
  chip.dataset.state = adapter.fallback ? 'warn' : 'ok';
  $('gpu-name').textContent = describeGpu(adapter);
  chip.title = `Largest GPU buffer ${formatBytes(adapter.maxBufferSize)}`;
  if (adapter.fallback) {
    notice.className = 'notice';
    notice.append(el('p', { text: 'This browser is using a software GPU. Models will run, but slowly. A hardware GPU or updated drivers make a large difference.' }));
    notice.hidden = false;
  } else {
    notice.hidden = true;
  }
  $('start-recommended').hidden = Boolean(state.loaded);
  setPhase(state.phase === 'starting' ? 'idle' : state.phase);
}

// ---- Model list ----

function cachedEntry(key) {
  return state.cache.models.find((m) => m.key === key);
}

function catalogEntry(m) {
  const key = cacheKey(m.repo, m.file);
  const split = Boolean(splitParts(m.file));
  return { kind: 'hf', id: m.id, key, repo: m.repo, file: m.file, revision: 'main', url: hfUrl(m.repo, m.file), bytes: m.bytes, name: m.name, resolve: split };
}

const ALL = [...MODELS, ...LARGE];

function renderModels() {
  const busy = state.phase === 'loading' || state.phase === 'generating' || ['agent','preparing'].includes(state.phase) || !state.adapter?.ok;
  const item = (m) => {
    const key = cacheKey(m.repo, m.file);
    const cached = cachedEntry(key);
    const saved = cached?.complete && cached.stored === cached.bytes;
    const partial = cached && !saved && cached.stored > 0;
    const running = state.loaded?.key === key;
    const tags = [
      el('span', { class: 'tag', text: m.quant }),
      running ? el('span', { class: 'tag run', text: 'Running' }) : null,
      saved && !running ? el('span', { class: 'tag ok', text: 'Saved' }) : null,
      partial ? el('span', { class: 'tag', text: `Paused at ${Math.round((cached.stored / cached.bytes) * 100)}%` }) : null,
      m.recommended && !saved && !running ? el('span', { class: 'tag rec', text: 'Recommended' }) : null,
      m.params ? el('span', { class: 'tag', text: m.params }) : null,
      el('span', { class: 'tag', text: `${m.maker} · ${m.license}` }),
    ];
    const button = el('button', {
      class: 'model', type: 'button', disabled: busy || running, 'aria-current': running ? 'true' : null,
      onclick: () => startLoad(catalogEntry(m)),
    },
    el('span', { class: 'row' }, el('span', { class: 'name', text: m.name }), el('span', { class: 'size', text: formatBytes(m.bytes) })),
    el('span', { class: 'note', text: m.note }),
    el('span', { class: 'meta' }, ...tags));
    const li = el('li', {}, button);
    if (cached && !running) {
      li.append(el('div', { class: 'model-actions' }, el('button', {
        class: 'remove', type: 'button', disabled: busy, text: saved ? 'Remove download' : 'Discard partial download',
        'aria-label': `Remove ${m.name} from this browser`,
        onclick: () => worker.postMessage({ type: 'removeCache', key }),
      })));
    }
    return li;
  };
  const items = MODELS.map(item);
  $('large-list').replaceChildren(...LARGE.map(item));
  const list = $('model-list');
  // Downloads that are not in the catalog.
  for (const c of state.cache.models) {
    if (ALL.some((m) => cacheKey(m.repo, m.file) === c.key)) continue;
    const running = state.loaded?.key === c.key;
    const entry = { kind: 'hf', id: c.key, key: c.key, repo: c.repo, file: c.file, revision: c.revision || 'main', url: c.url, bytes: c.bytes, name: c.file, parts: c.parts?.length > 1 ? c.parts.map((p) => ({ ...p, url: hfUrl(c.repo, p.file, c.revision || 'main') })) : null };
    items.push(el('li', {},
      el('button', { class: 'model', type: 'button', disabled: busy || running, 'aria-current': running ? 'true' : null, onclick: () => startLoad(entry) },
        el('span', { class: 'row' }, el('span', { class: 'name', text: c.file.split('/').pop().replace(/(-\d{5}-of-\d{5})?\.gguf$/i, '') }), el('span', { class: 'size', text: formatBytes(c.bytes) })),
        el('span', { class: 'note', text: c.repo }),
        el('span', { class: 'meta' }, running ? el('span', { class: 'tag run', text: 'Running' }) : el('span', { class: 'tag ok', text: c.complete ? 'Saved' : 'Partial' }))),
      running ? null : el('div', { class: 'model-actions' }, el('button', { class: 'remove', type: 'button', disabled: busy, text: 'Remove download', onclick: () => worker.postMessage({ type: 'removeCache', key: c.key }) }))));
  }
  list.replaceChildren(...items);
  $('hf-form').querySelector('button').disabled = busy;
  $('file-input').disabled = busy;
  renderStorage();
}

function renderStorage() {
  const box = $('storage');
  const { usage, quota, supported, models } = state.cache;
  if (!supported) {
    box.hidden = false;
    box.textContent = 'This browser cannot save models. Open GGUF files from your device instead.';
    return;
  }
  if (!quota) { box.hidden = true; return; }
  const stored = models.reduce((sum, m) => sum + (m.stored || 0), 0);
  box.hidden = false;
  const meter = el('div', { class: 'meter' }, el('span'));
  meter.firstChild.style.setProperty('width', `${Math.min(100, (usage / quota) * 100).toFixed(1)}%`);
  box.replaceChildren(
    el('div', { text: `Saved models: ${formatBytes(stored)}` }),
    meter,
    el('div', { text: `${formatBytes(quota - usage)} of browser storage free` }),
  );
}

// ---- Loading ----

let loadStarted = 0;

async function startLoad(source) {
  if (['agent','preparing'].includes(state.phase)) { $('status-line').textContent = 'Stop the Pi task before loading another model.'; return; }
  if (!state.adapter?.ok) return;
  closeDrawer();
  if (state.phase === 'generating') return;
  // A file from disk that is one of the catalog models gets its friendly name.
  const first = source.kind === 'file' ? source.files[0].name : '';
  const known = source.kind === 'file' ? ALL.find((m) => m.file.split('/').pop().toLowerCase() === first.toLowerCase()) : null;
  const label = known ? known.name : source.kind === 'file' ? first.replace(/(-\d{5}-of-\d{5})?\.gguf$/i, '') : source.name;
  state.loading = { label, key: known ? cacheKey(known.repo, known.file) : source.key, id: known ? known.id : source.id, kind: source.kind };
  state.loaded = null;
  for(const m of state.messages)m.developmentView?.dispose();
  state.messages = [];state.developmentActive=false;
  renderMessages();
  $('loading-title').textContent = label;
  for (const li of $('loading-steps').children) li.dataset.state = '';
  const saved = source.kind === 'hf' && cachedEntry(source.key)?.complete;
  setStep(source.kind === 'file' || saved ? 'upload' : 'download', source.kind === 'file' || saved);
  setProgress(0, 1, '');
  $('loading-step').textContent = saved ? 'Saved on this device' : source.kind === 'file' ? 'From this device' : 'Downloading';
  loadStarted = performance.now();
  setPhase('loading');
  if (source.kind === 'hf') remember('evolve-llm-last', source.id);
  if (source.kind === 'hf' && (source.resolve || !source.bytes) && !source.parts) {
    // Split models and pasted files: ask Hugging Face for every part and its size first.
    try {
      const r = await resolveParts(source.repo, source.file, source.revision);
      source = { ...source, bytes: r.bytes, parts: r.parts.length > 1 ? r.parts : null, url: r.parts[0].url };
    } catch (e) {
      onError({ during: 'load', message: e.message });
      return;
    }
  }
  worker.postMessage({ type: 'load', source, ctx: Number(state.settings.ctx), gpu: state.settings.gpu, gpuMemory: state.settings.gpuMemory });
}

function setStep(step, skipDownload = false) {
  const order = ['download', 'upload', 'prepare'];
  for (const li of $('loading-steps').children) {
    const i = order.indexOf(li.dataset.step);
    const at = order.indexOf(step);
    li.dataset.state = i < at ? (li.dataset.step === 'download' && skipDownload ? 'skip' : 'done') : i === at ? 'active' : '';
  }
}

function setProgress(loaded, total, detail) {
  const pct = total ? Math.min(100, (loaded / total) * 100) : 0;
  const bar = $('loading-bar');
  bar.firstElementChild.style.setProperty('width', `${pct.toFixed(1)}%`);
  bar.setAttribute('aria-valuenow', String(Math.round(pct)));
  $('loading-detail').textContent = detail;
}

function onProgress({ phase, loaded, total, rate, part, parts }) {
  const bar = $('loading-bar');
  bar.classList.toggle('indeterminate', phase === 'prepare');
  if (phase === 'download') {
    $('loading-step').textContent = parts > 1 ? `Downloading part ${part} of ${parts} from Hugging Face` : 'Downloading from Hugging Face';
    setStep('download');
    const left = rate > 0 ? (total - loaded) / rate : 0;
    setProgress(loaded, total, `${formatBytes(loaded)} of ${formatBytes(total)} · ${formatBytes(rate)}/s${left > 1 ? ` · about ${formatDuration(left)} left` : ''}`);
  } else if (phase === 'upload') {
    $('loading-step').textContent = 'Moving weights to the GPU';
    setStep('upload', state.loading?.kind === 'file' || $('loading-steps').firstElementChild.dataset.state === 'skip');
    setProgress(loaded, total, `${formatBytes(loaded)} of ${formatBytes(total)} · ${formatBytes(rate)}/s`);
  } else {
    $('loading-step').textContent = 'Preparing the context';
    setStep('prepare', $('loading-steps').firstElementChild.dataset.state === 'skip');
    setProgress(1, 1, 'Allocating the key-value cache and compiling GPU kernels');
  }
}

function formatDuration(s) {
  if (s < 90) return `${Math.round(s)} s`;
  if (s < 5400) return `${Math.round(s / 60)} min`;
  return `${(s / 3600).toFixed(1)} h`;
}

function onLoaded({ model, chat, source }) {
  const label = state.loading?.label || chat.name;
  state.loaded = { ...source, key: state.loading?.key ?? source.key, label, info: model, chat };
  state.loading = null;
  $('loading-bar').classList.remove('indeterminate');
  const secs = (performance.now() - loadStarted) / 1000;
  const cfg = model.config;
  const types = Object.keys(model.weight_types).join(', ');
  $('ready-title').textContent = `${label} is running on your GPU`;
  const active = model.active_parameters < model.parameters * 0.9 ? `, ${formatParams(model.active_parameters)} active per token` : '';
  const pl = chat.placement || {};
  const where = pl.streaming
    ? ` · ${formatBytes(chat.weight_bytes + chat.state_bytes)} on the GPU, ${formatBytes(pl.streamed_bytes)} read from storage as needed${pl.expert_slots ? ` (an expert cache of ${pl.expert_slots.toLocaleString()} of ${pl.experts_total.toLocaleString()} experts)` : ` (${pl.resident_layers} of ${cfg.n_layer} layers on the GPU)`}`
    : ` · ${formatBytes(chat.weight_bytes + chat.state_bytes)} of GPU memory`;
  $('ready-meta').textContent = `${formatParams(model.parameters)} parameters${active} · ${types} · ${cfg.n_layer} layers · ${chat.context.toLocaleString()}-token context${where} · ready in ${secs.toFixed(1)} s`;
  $('suggestions').replaceChildren(...SUGGESTIONS.map((s) => el('button', { type: 'button', text: s, onclick: () => send(s) })));
  $('status-line').textContent = 'Replies are generated on this device. Responses can be wrong; check anything important.';
  setPhase('ready');
  $('prompt').focus();
}

function formatParams(n) {
  if (n >= 1e12) return `${(n / 1e12).toFixed(2)}T`;
  return n >= 1e9 ? `${(n / 1e9).toFixed(n >= 1e11 ? 0 : 1)}B` : `${Math.round(n / 1e6)}M`;
}

// ---- Conversation ----

function renderMessages() {
  const list = $('messages');
  const nodes=state.messages.map((m,i)=>messageNode(m,i));
  for(const child of [...list.children])if(!nodes.includes(child))child.remove();
  nodes.forEach((node,i)=>{if(list.children[i]!==node)list.insertBefore(node,list.children[i]||null);});
  $('ready').hidden = !(state.loaded && !state.messages.length && state.phase !== 'loading');
}

function copyText(text, button) {
  const done = () => {
    if (!button) return;
    const old = button.textContent;
    button.textContent = 'Copied';
    setTimeout(() => { button.textContent = old; }, 1200);
  };
  navigator.clipboard?.writeText(text).then(done, () => {});
}

function safeHref(url) {
  try {
    const u = new URL(url);
    return u.protocol === 'https:' || u.protocol === 'http:' ? u.href : null;
  } catch {
    return null;
  }
}

function stepNode(step) {
  const what = step.name === 'web_search'
    ? `Searched the web for “${step.args?.query || ''}”`
    : `Read ${String(step.args?.url || '').replace(/^https?:\/\//, '').slice(0, 80)}`;
  if (!step.done) return el('li', { class: 'running', text: what });
  const links = (step.sources || []).map((s) => {
    const href = safeHref(s.url);
    return el('li', {}, href ? el('a', { href, target: '_blank', rel: 'noopener noreferrer', text: s.title || href }) : el('span', { text: s.title || '' }));
  });
  if (!links.length) return el('li', { text: `${what} · nothing found` });
  return el('li', {}, el('details', {}, el('summary', { text: `${what} · ${links.length} ${links.length === 1 ? 'source' : 'sources'}` }), el('ol', {}, ...links)));
}

function fillAssistant(bubble, m) {
  if(m.development){const answer=el('div',{class:'answer'});answer.append(renderMarkdown(document,m.content,copyText));bubble.replaceChildren(answer);return;}
  const parts = splitThinking(stripToolCalls(m.content));
  const nodes = [];
  if (m.steps?.length) nodes.push(el('ul', { class: 'web-steps', 'aria-label': 'Web activity' }, ...m.steps.map(stepNode)));
  for (const p of parts) {
    if (p.kind === 'think') {
      const words = p.text.trim().split(/\s+/).filter(Boolean).length;
      const details = el('details', { class: 'think', open: !p.done ? true : null },
        el('summary', { text: p.done ? `Reasoning · ${words} words` : 'Thinking…' }),
        el('div', { class: 'think-body', text: p.text.trim() }));
      nodes.push(details);
    } else {
      const div = el('div', { class: 'answer' });
      div.append(renderMarkdown(document, p.text.replace(/^\s+/, ''), copyText));
      nodes.push(div);
    }
  }
  if (m === state.live) {
    const last = nodes[nodes.length - 1];
    const target = last?.classList.contains('answer') ? last.lastElementChild || last : null;
    if (target && !target.matches('figure')) target.classList.add('cursor');
    else nodes.push(el('span', { class: 'cursor' }));
  }
  bubble.replaceChildren(...nodes);
}

function messageNode(m, i) {
  if (m.error) {
    return m.element ||= el('li', { class: 'msg error' }, el('div', { class: 'bubble', text: m.content }));
  }
  if (m.role === 'user') {
    return m.element ||= el('li', { class: 'msg user' }, el('div', { class: 'bubble', text: m.content }));
  }
  const bubble=m.element?.querySelector('.bubble')||el('div',{class:'bubble'});
  fillAssistant(bubble,m);
  const li=m.element ||= el('li',{class:'msg assistant','data-index':i},el('span',{class:'who',text:state.loaded?.label||'Model'}),bubble);
  li.querySelector(':scope > .msg-foot')?.remove();li.querySelector(':scope > .trimmed')?.remove();
  if(m.developmentView&&m.developmentView.root.parentElement!==li)li.append(m.developmentView.root);
  if (m !== state.live) {
    const last = i === state.messages.length - 1;
    li.append(el('div', { class: 'msg-foot' },
      m.stats ? el('span', { class: 'msg-stats', text: m.stats }) : null,
      el('span', { class: 'msg-actions' },
        el('button', { type: 'button', text: 'Copy', onclick: (e) => copyText(splitThinking(m.content).filter((p) => p.kind === 'answer').map((p) => p.text.trim()).join('\n\n'), e.currentTarget) }),
        last && state.phase === 'ready' ? el('button', { type: 'button', text: 'Regenerate', onclick: regenerate }) : null)));
    if (m.dropped) li.append(el('span', { class: 'trimmed', text: `Earlier messages (${m.dropped}) were left out to fit the context.` }));
  }
  return li;
}

let frame = 0;
function scheduleLiveRender() {
  if (frame) return;
  frame = requestAnimationFrame(() => {
    frame = 0;
    const node = $('messages').lastElementChild;
    if (!node || !state.live) return;
    const scroller = $('scroll');
    const stick = scroller.scrollHeight - scroller.scrollTop - scroller.clientHeight < 120;
    fillAssistant(node.querySelector('.bubble'), state.live);
    if (stick) scroller.scrollTop = scroller.scrollHeight;
  });
}

function conversation() {
  const msgs = [];
  const system = state.settings.system.trim();
  if (system) msgs.push({ role: 'system', content: system });
  for (const m of state.messages) if (!m.error && (m.role === 'user' || m.role === 'assistant')) msgs.push({ role: m.role, content: m.role === 'assistant' ? stripToolCalls(m.content) : m.content });
  return msgs;
}

function syncWebToggle() {
  const on = Boolean(state.settings.internet);
  const b = $('web-toggle');
  b.setAttribute('aria-pressed', String(on));
  b.title = on ? 'Web search is on: search terms go to Wikipedia, DuckDuckGo and Jina' : 'Let the model search the web';
}

function send(text) {
  text = text.trim();
  if (!text || state.phase !== 'ready') return;
  state.messages.push({ role: 'user', content: text });
  runResponse();
}

function regenerate() {
  if (state.phase !== 'ready') return;
  while (state.messages.length && state.messages[state.messages.length - 1].role !== 'user') state.messages.pop().developmentView?.dispose();
  if (state.messages.length) runResponse();
}

function runResponse(){
  const question=state.messages.at(-1)?.content||'';
  if(wantsDevelopment(question,$('chat-mode').value,state.developmentActive))runDevelopment(question);
  else runGeneration();
}

async function runDevelopment(question){
  const context=state.messages.slice(0,-1).filter(m=>!m.error).slice(-6).map(m=>`${m.role}: ${m.content}`).join('\n').slice(-6000);
  const m={role:'assistant',content:'Preparing your workspace…',development:true,started:performance.now()};
  m.developmentView=createDevelopmentView({openWorkspace:async()=>{try{await(await ensureWorkbench()).open();}catch(error){$('status-line').textContent=error.message;}}});
  state.live=m;state.messages.push(m);state.developmentActive=true;setPhase('preparing');renderMessages();
  $('scroll').scrollTop=$('scroll').scrollHeight;
  try{
    const session=await ensureWorkbench();
    if(m.cancelRequested)throw new Error('Task cancelled.');
    let starter;
    if(wantsSnakeStarter(question)){
      const response=await fetch(new URL('./examples/snake.html',import.meta.url));
      if(!response.ok)throw new Error('The Snake starter could not be loaded.');
      starter=await response.text();
    }
    if(m.cancelRequested)throw new Error('Task cancelled.');
    m.content='Pi is working on your request…';scheduleLiveRender();
    const browsing=wantsBrowser(question)||(state.lastTaskBrowsing&&!starter&&question.length<240&&!/\b(make|build|create|write|code|game|app)\b/i.test(question));state.lastTaskBrowsing=browsing;
    const result=await session.runTask(question.replace(/^\s*pi\s+/i,''),{context,starter,partial:true,browser:browsing?()=>import('./browser-session.mjs').then(b=>b.ensureBrowser({show:true})):undefined,confirmBrowserAction:t=>Promise.resolve(confirm(t+'\n\nAllow Pi to do this?')),onEvent:e=>{m.developmentView.event(e);if(e.type==='starter'){m.content='Your Snake starter is ready below. Pi is applying your request…';scheduleLiveRender();}},preview:(...args)=>m.developmentView.preview(...args)});
    m.content=developmentSummary(result,m.developmentView.check);
    m.stats=`Pi · ${result.calls} tool call${result.calls===1?'':'s'} · ${result.changes} file${result.changes===1?'':'s'} changed · ${result.errors} tool errors`;
    m.developmentView.finish(result);
  }catch(error){m.content='The development task stopped: '+String(error.message||error);m.developmentView.finish({error:m.content,artifacts:[]});}
  finally{state.live=null;setPhase(state.loaded?'ready':'idle');renderMessages();$('scroll').scrollTop=$('scroll').scrollHeight;$('status-line').textContent='Files stay in your browser. Ask for changes here, or open the workspace.';}
}

function runGeneration() {
  const now = new Date();
  const s = state.settings;
  const history = conversation();
  state.live = { role: 'assistant', content: '', started: performance.now() };
  state.messages.push(state.live);
  setPhase('generating');
  renderMessages();
  $('scroll').scrollTop = $('scroll').scrollHeight;
  worker.postMessage({
    type: 'generate',
    messages: history,
    options: { date: [now.getFullYear(), now.getMonth() + 1, now.getDate()], enable_thinking: Boolean(s.thinking) },
    sampler: { temperature: Number(s.temperature), top_p: Number(s.top_p), top_k: Number(s.top_k), min_p: Number(s.min_p), repeat_penalty: Number(s.repeat_penalty), repeat_last_n: 64, seed: (Math.random() * 2 ** 32) >>> 0 },
    maxTokens: Number(s.maxTokens),
    internet: { enabled: Boolean(s.internet), jinaKey: s.jinaKey || '' },
  });
}

function onPrefill(p) {
  if (!state.live) return;
  state.live.prefill ??= p;
  if (p.dropped) state.live.dropped = p.dropped;
}

function onTool(msg, done) {
  const m = state.live;
  if (!m) return;
  m.steps ??= [];
  if (done) {
    const step = [...m.steps].reverse().find((s) => !s.done && s.name === msg.name) || m.steps[m.steps.length - 1];
    if (step) Object.assign(step, { done: true, sources: msg.sources });
  } else {
    m.steps.push({ name: msg.name, args: msg.args, done: false });
  }
  scheduleLiveRender();
}

function onDone(d) {
  const m = state.live;
  if (!m) return;
  const p = m.prefill || {};
  const rate = d.tokens > 0 && d.ms > 0 ? (d.tokens / (d.ms / 1000)).toFixed(1) : '0';
  const prompt = p.computed ? ` · read ${p.computed} prompt tokens in ${(p.ms / 1000).toFixed(2)} s${p.reused ? ` (${p.reused} reused)` : ''}` : '';
  const why = d.reason === 'stopped' ? ' · stopped' : d.reason === 'length' ? ' · reached the reply limit' : '';
  const st = d.stream || {};
  const stream = st.bytes_read ? ` · read ${formatBytes(st.bytes_read)} from storage${st.expert_requests ? `, ${Math.round((100 * st.expert_hits) / st.expert_requests)}% of experts already on the GPU` : ''}` : '';
  m.stats = `${d.tokens} tokens · ${rate} tokens/s${prompt}${why}${stream}`;
  if (!m.content.trim()) m.content = d.reason === 'stopped' ? '' : '(no reply)';
  state.live = null;
  $('status-line').textContent = `Context: ${d.used.toLocaleString()} of ${d.context.toLocaleString()} tokens used`;
  setPhase('ready');
  renderMessages();
}

function onError({ during, message }) {
  if (during === 'load') {
    state.loading = null;
    state.loaded = null;
    $('loading-bar').classList.remove('indeterminate');
    setPhase('idle');
    const notice = $('gpu-notice');
    notice.className = 'notice error';
    notice.replaceChildren(el('h2', { text: 'The model could not be loaded' }), el('p', { text: message }));
    notice.hidden = false;
    $('welcome').hidden = false;
    worker.postMessage({ type: 'listCache' });
    return;
  }
  if (during === 'generate') {
    if (state.live) {
      state.messages.pop();
      state.live = null;
    }
    state.messages.push({ role: 'assistant', error: true, content: message });
    setPhase(state.loaded ? 'ready' : 'idle');
    renderMessages();
    return;
  }
  $('status-line').textContent = message;
}

function onWorkerMessage(event) {
  const msg = event.data;
  if (msg.requestId) {
    if (!agentRequest || msg.requestId !== agentRequest.id) return;
    if (msg.type === 'agent_event' && msg.event.type === 'token') agentRequest.onToken?.(msg.event.text);
    else if (msg.type === 'agent_done') finishAgent(agentRequest.aborted ? new Error('Pi model turn cancelled.') : null, msg);
    else if (msg.type === 'error') finishAgent(new Error(msg.message));
    return;
  }
  switch (msg.type) {
    case 'adapter': showGpu(msg.adapter); break;
    case 'cache': state.cache = msg; renderModels(); break;
    case 'progress': onProgress(msg); break;
    case 'inspected': break;
    case 'loaded': onLoaded(msg); break;
    case 'prefill': onPrefill(msg); break;
    case 'token':
      if (state.live) {
        state.live.content += msg.text;
        scheduleLiveRender();
      }
      break;
    case 'tool': onTool(msg, false); break;
    case 'tool-result': onTool(msg, true); break;
    case 'round':
      // The model's next turn after a tool result replaces the tool-call text.
      if (state.live) { state.live.content = ''; scheduleLiveRender(); }
      break;
    case 'done': onDone(msg); break;
    case 'error': onError(msg); break;
    case 'unloaded': break;
  }
};
function onWorkerError(e) {
  if (agentRequest) finishAgent(new Error(e.message || 'Model worker failed.'));
  state.loaded = null; setPhase('idle');
  showGpu({ ok: false, reason: 'no-adapter' });
  $('status-line').textContent = `The engine could not start: ${e.message || 'worker error'}`;
};

// ---- Controls ----

const prompt = $('prompt');
function autosize() {
  prompt.style.setProperty('height', 'auto');
  prompt.style.setProperty('height', `${Math.min(prompt.scrollHeight, 220)}px`);
}
prompt.addEventListener('input', autosize);
prompt.addEventListener('keydown', (e) => {
  if (e.key === 'Enter' && !e.shiftKey && !e.isComposing) {
    e.preventDefault();
    $('composer').requestSubmit();
  }
});
$('composer').addEventListener('submit', (e) => {
  e.preventDefault();
  if (state.phase !== 'ready') return;
  const text = prompt.value;
  if (!text.trim()) return;
  prompt.value = '';
  autosize();
  send(text);
});
function stopCurrent(){if(state.live?.development){state.live.cancelRequested=true;workbench?.cancel();}else worker.postMessage({type:'stop'});}
$('stop').addEventListener('click',stopCurrent);
$('web-toggle').addEventListener('click', () => {
  state.settings.internet = !state.settings.internet;
  networkChanged();
  saveSettings();
  syncWebToggle();
  $('status-line').textContent = state.settings.internet
    ? 'Web search is on. Search terms and pages the model opens go to Wikipedia, DuckDuckGo and Jina Reader; the conversation stays here.'
    : 'Web search is off. Nothing leaves this device.';
});
document.addEventListener('keydown', (e) => {
  if(e.key==='Escape'&&['generating','agent','preparing'].includes(state.phase))stopCurrent();
});
$('cancel-load').addEventListener('click', () => worker.postMessage({ type: 'cancel' }));
$('new-chat').addEventListener('click', () => {
  if (state.phase !== 'ready') return;
  for(const m of state.messages)m.developmentView?.dispose();
  state.messages = [];state.developmentActive=false;
  worker.postMessage({ type: 'reset' });
  renderMessages();
  setPhase('ready');
  $('status-line').textContent = 'Started a new conversation.';
  prompt.focus();
});
$('start-recommended').addEventListener('click', () => {
  const last = ALL.find((m) => m.id === recall('evolve-llm-last'));
  startLoad(catalogEntry(last || MODELS.find((m) => m.recommended)));
});
const HF_HELP = $('hf-help').textContent;

function hfSource(ref, file) {
  const first = splitParts(file)?.[0] || file;
  const key = cacheKey(ref.repo, first, ref.revision);
  return { kind: 'hf', id: key, key, repo: ref.repo, file: first, revision: ref.revision, url: hfUrl(ref.repo, first, ref.revision), bytes: 0,
    name: first.split('/').pop().replace(/(-\d{5}-of-\d{5})?\.gguf$/i, ''), resolve: true };
}

$('hf-form').addEventListener('submit', async (e) => {
  e.preventDefault();
  const help = $('hf-help');
  const results = $('hf-results');
  results.hidden = true;
  try {
    const ref = parseHfReference($('hf-input').value);
    help.classList.remove('error');
    help.textContent = HF_HELP;
    if (ref.file) {
      startLoad(hfSource(ref, ref.file));
      return;
    }
    help.textContent = `Looking up ${ref.repo}…`;
    const groups = await listRepo(ref.repo, ref.revision);
    if (!groups.length) throw new Error('That repository has no GGUF files.');
    help.textContent = `${groups.length} GGUF ${groups.length === 1 ? 'model' : 'models'} in ${ref.repo}. Choose one:`;
    results.replaceChildren(...groups.map((g) => el('li', {}, el('button', { type: 'button', onclick: () => startLoad(hfSource(ref, g.file)) },
      el('span', { class: 'name', text: g.file.split('/').pop().replace(/(-\d{5}-of-\d{5})?\.gguf$/i, '') }),
      el('span', { class: 'size', text: `${formatBytes(g.bytes)}${g.parts.length > 1 ? ` · ${g.parts.length} files` : ''}` })))));
    results.hidden = false;
  } catch (err) {
    help.classList.add('error');
    help.textContent = err.message;
  }
});
$('file-input').addEventListener('change', (e) => {
  const files = [...(e.target.files || [])].sort((a, b) => a.name.localeCompare(b.name));
  e.target.value = '';
  if (files.length) startLoad({ kind: 'file', files, key: null, id: null });
});

// Drawer on narrow screens.
function openDrawer() { app.dataset.drawer = 'open'; $('open-models').setAttribute('aria-expanded', 'true'); $('scrim').hidden = false; }
function closeDrawer() { delete app.dataset.drawer; $('open-models').setAttribute('aria-expanded', 'false'); $('scrim').hidden = true; }
$('open-models').addEventListener('click', () => (app.dataset.drawer ? closeDrawer() : openDrawer()));
$('scrim').addEventListener('click', closeDrawer);
const topBar = document.querySelector('.top');
const syncTop = () => document.documentElement.style.setProperty('--top-h', `${topBar.offsetHeight}px`);
new ResizeObserver(syncTop).observe(topBar);

// Settings dialog.
const dialog = $('settings');
const form = $('settings-form');
const RANGES = ['temperature', 'top_p', 'top_k', 'min_p', 'repeat_penalty', 'maxTokens'];
function fillSettings() {
  const s = state.settings;
  form.elements.system.value = s.system;
  for (const k of RANGES) {
    form.elements[k].value = s[k];
    form.elements[`${k}Out`].value = s[k];
  }
  form.elements.ctx.value = String(s.ctx);
  form.elements.gpu.value = s.gpu;
  form.elements.gpuMemory.value = String(s.gpuMemory);
  form.elements.thinking.checked = Boolean(s.thinking);
  form.elements.internet.checked = Boolean(s.internet);
  form.elements.jinaKey.value = s.jinaKey || '';
}
form.addEventListener('input', (e) => {
  const t = e.target;
  if (!t.name) return;
  if (t.type === 'checkbox') {
    state.settings[t.name] = t.checked;
    if (t.name === 'internet') { syncWebToggle(); networkChanged(); }
  }
  else if (t.type === 'range') {
    state.settings[t.name] = Number(t.value);
    form.elements[`${t.name}Out`].value = t.value;
  } else if (t.name === 'ctx') state.settings.ctx = Number(t.value);
  else if (t.name === 'gpu') {
    state.settings.gpu = t.value;
    worker.postMessage({ type: 'adapter', gpu: t.value });
  }
  else state.settings[t.name] = t.value;
  saveSettings();
});
form.addEventListener('change', (e) => {
  if (['ctx', 'gpu', 'gpuMemory'].includes(e.target.name) && state.loaded) $('status-line').textContent = 'This setting applies the next time a model loads.';
});
$('open-settings').addEventListener('click', () => { fillSettings(); dialog.showModal(); });
$('reset-settings').addEventListener('click', () => {
  state.settings = { ...DEFAULTS };
  saveSettings();
  fillSettings();
  syncWebToggle();
  networkChanged();
  worker.postMessage({ type: 'adapter', gpu: state.settings.gpu });
});

setPhase('starting');
syncWebToggle();

// ---- Terminal and Pi: a lease on the existing model, not a second GPU copy ----
let workbench=null, workbenchPromise=null, agentRequest=null, agentSequence=0;
worker.onmessage=onWorkerMessage;worker.onerror=onWorkerError;
const terminalButton=el('button',{class:'ghost',type:'button',id:'open-terminal',text:'Terminal',title:'WASM terminal and Pi coding agent'});
$('open-settings').before(terminalButton);
function finishAgent(error,value) {
  const request=agentRequest;if(!request)return;agentRequest=null;clearTimeout(request.timer);clearTimeout(request.cancelTimer);request.signal?.removeEventListener('abort',request.abort);
  error?request.reject(error):request.resolve(value);
}
function restartEngine(reason) {
  worker.terminate();finishAgent(new Error(reason));state.loaded=null;state.loading=null;
  worker=new Worker(new URL('./worker.js',import.meta.url),{type:'module'});worker.onmessage=onWorkerMessage;worker.onerror=onWorkerError;
  setPhase('starting');worker.postMessage({type:'hello',gpu:state.settings.gpu});$('status-line').textContent=reason+' Choose a saved model to reload it.';
}
function agentTurn(messages,tools,{signal,onToken,maxTokens=2048}={}) {
  if(state.phase!=='agent'||agentRequest)return Promise.reject(new Error('The model is busy.'));
  if(signal?.aborted)return Promise.reject(new Error('Pi model turn cancelled.'));
  return new Promise((resolve,reject)=>{
    const id=++agentSequence;
    const abort=()=>{if(agentRequest?.id!==id)return;agentRequest.aborted=true;worker.postMessage({type:'stop'});agentRequest.cancelTimer=setTimeout(()=>restartEngine('Pi cancellation released an unresponsive worker.'),10000)};
    agentRequest={id,resolve,reject,onToken,signal,abort,timer:setTimeout(()=>restartEngine('Pi model turn exceeded its two-minute limit.'),120000)};
    signal?.addEventListener('abort',abort,{once:true});
    worker.postMessage({type:'agent_turn',requestId:id,messages,tools,maxTokens:Math.max(64,Math.min(4096,Number(maxTokens)||2048)),sampler:{temperature:0,top_p:.95,top_k:40,min_p:.05,repeat_penalty:1.1,repeat_last_n:64,seed:1}});
  });
}
function networkChanged() {
  worker.postMessage({type:'network_policy',enabled:Boolean(state.settings.internet)});workbench?.setNetwork();
}
async function ensureWorkbench(){
  workbenchPromise ||= import('./workbench.mjs').then(({mountWorkbench})=>mountWorkbench({
    ready:()=>['ready','preparing'].includes(state.phase)&&Boolean(state.loaded),turn:agentTurn,modelName:()=>state.loaded?.label||'Local model',
    lease:()=>{if(!['ready','preparing'].includes(state.phase)||!state.loaded)throw new Error('The model is not ready.');setPhase('agent');let released=false;return()=>{if(!released){released=true;setPhase(state.loaded?(state.live?.development?'preparing':'ready'):'idle');}};},
    getNetwork:()=>({enabled:Boolean(state.settings.internet),jinaKey:state.settings.jinaKey||''}),
    setNetwork:enabled=>{state.settings.internet=enabled;saveSettings();syncWebToggle();networkChanged();},
  })).catch(error=>{workbenchPromise=null;throw error;});
  workbench=await workbenchPromise;return workbench;
}
terminalButton.addEventListener('click',async()=>{
  terminalButton.disabled=true;
  try{await(await ensureWorkbench()).open();}catch(error){$('status-line').textContent=String(error.message||error);}
  finally{terminalButton.disabled=false;}
});
// ---- Browser: a web engine compiled to WebAssembly, shared by the person and Pi ----
const browserButton=el('button',{class:'ghost',type:'button',id:'open-browser',text:'Browser',title:'Web browser engine in WebAssembly, shared with Pi'});
$('open-settings').before(browserButton);
browserButton.addEventListener('click',async()=>{
  browserButton.disabled=true;
  try{const {openBrowser,isBrowserOpen,closeBrowser}=await import('./browser-session.mjs');if(isBrowserOpen())closeBrowser();else await openBrowser();}
  catch(error){$('status-line').textContent=String(error.message||error);}
  finally{browserButton.disabled=false;}
});
$('chat-mode').value=recall('evolve-llm-chat-mode')||'auto';
if(!$('chat-mode').value)$('chat-mode').value='auto';
$('chat-mode').addEventListener('change',()=>remember('evolve-llm-chat-mode',$('chat-mode').value));

worker.postMessage({ type: 'hello', gpu: state.settings.gpu });
